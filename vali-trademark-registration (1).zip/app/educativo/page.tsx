import { Button } from "@/components/ui/button"
import {
  AlertTriangle,
  Ban,
  Clock,
  DollarSign,
  FileWarning,
  ShieldAlert,
  Gavel,
  ArrowRight,
  AlertCircle,
  Trash2,
  Building,
  Scale,
} from "lucide-react"
import Image from "next/image"

export default function EducativoPage() {
  return (
    <div className="flex flex-col min-h-screen bg-background text-white">
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative py-20 overflow-hidden">
          <div className="absolute inset-0 z-0">
            <Image
              src="/placeholder.svg?height=800&width=1600"
              alt="Empresário preocupado"
              fill
              className="object-cover brightness-[0.3]"
            />
          </div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl">
              <div className="inline-flex items-center gap-2 bg-red-500/20 text-red-400 px-4 py-2 rounded-full mb-6">
                <AlertTriangle size={18} />
                <span className="font-semibold">ALERTA DE RISCO EMPRESARIAL</span>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
                Sua Marca Pode Não Ser Sua: <span className="text-red-500">O Pesadelo Real</span> de Quem Não Registra
              </h1>
              <p className="text-xl mb-8 text-gray-300">
                Milhares de empreendedores brasileiros perderam tudo o que construíram por anos porque negligenciaram um
                único documento. Você pode ser o próximo.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white font-bold px-8 py-6 text-lg">
                  Proteja Sua Marca Agora
                  <ArrowRight className="ml-2" />
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-white text-white hover:bg-white/10 px-8 py-6 text-lg"
                >
                  Verificar Risco Gratuito
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Warning Banner */}
        <section className="bg-red-600 py-6">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <AlertCircle className="h-8 w-8 text-white" />
                <p className="text-white font-semibold text-lg">
                  A cada 24 horas, 17 empresas brasileiras são notificadas por uso indevido de marca
                </p>
              </div>
              <Button className="bg-white text-red-600 hover:bg-gray-100 whitespace-nowrap">Avaliar Meu Risco</Button>
            </div>
          </div>
        </section>

        {/* Real Cases Section */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-6">Histórias Reais: O Lado Sombrio de Não Registrar</h2>
              <p className="text-xl text-gray-400 max-w-3xl mx-auto">
                Estes empreendedores perderam tudo o que construíram porque acreditaram no mito de que "não precisavam
                registrar agora". Não cometa o mesmo erro.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-gray-900 border border-red-500/30 rounded-xl p-6 shadow-lg">
                <div className="flex items-center gap-4 mb-4">
                  <Image
                    src="/placeholder.svg?height=80&width=80"
                    width={80}
                    height={80}
                    alt="Carlos Mendes"
                    className="rounded-full border-2 border-red-500"
                  />
                  <div>
                    <h3 className="font-bold">Carlos Mendes</h3>
                    <p className="text-gray-400">Proprietário de Restaurante</p>
                  </div>
                </div>
                <div className="relative">
                  <span className="absolute -top-2 -left-2 text-red-500 text-6xl opacity-20">"</span>
                  <p className="text-gray-300 relative z-10 italic">
                    Perdi tudo o que construí em 8 anos. Tive que mudar o nome, logotipo, cardápios, uniformes,
                    fachada... Os clientes não reconheciam mais o restaurante. O prejuízo ultrapassou R$ 300 mil, sem
                    contar os clientes perdidos.
                  </p>
                </div>
              </div>

              <div className="bg-gray-900 border border-red-500/30 rounded-xl p-6 shadow-lg">
                <div className="flex items-center gap-4 mb-4">
                  <Image
                    src="/placeholder.svg?height=80&width=80"
                    width={80}
                    height={80}
                    alt="Mariana Costa"
                    className="rounded-full border-2 border-red-500"
                  />
                  <div>
                    <h3 className="font-bold">Mariana Costa</h3>
                    <p className="text-gray-400">Proprietária de Loja de Roupas</p>
                  </div>
                </div>
                <div className="relative">
                  <span className="absolute -top-2 -left-2 text-red-500 text-6xl opacity-20">"</span>
                  <p className="text-gray-300 relative z-10 italic">
                    Recebi uma notificação extrajudicial exigindo que eu parasse de usar minha marca em 48 horas. Tive
                    que fechar a loja por 2 semanas e reabrir com outro nome. Perdi clientes fiéis e tive que explicar a
                    situação constrangedora para todos.
                  </p>
                </div>
              </div>

              <div className="bg-gray-900 border border-red-500/30 rounded-xl p-6 shadow-lg">
                <div className="flex items-center gap-4 mb-4">
                  <Image
                    src="/placeholder.svg?height=80&width=80"
                    width={80}
                    height={80}
                    alt="Ricardo Oliveira"
                    className="rounded-full border-2 border-red-500"
                  />
                  <div>
                    <h3 className="font-bold">Ricardo Oliveira</h3>
                    <p className="text-gray-400">Empresário de Tecnologia</p>
                  </div>
                </div>
                <div className="relative">
                  <span className="absolute -top-2 -left-2 text-red-500 text-6xl opacity-20">"</span>
                  <p className="text-gray-300 relative z-10 italic">
                    Fui condenado a pagar R$ 420 mil de indenização por uso indevido de marca. Quase falimos. Se eu
                    soubesse que o registro custava menos de 1% desse valor, teria feito imediatamente. Foi o pior erro
                    da minha vida empresarial.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Risks Section */}
        <section className="py-20 bg-gray-900">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <div className="inline-flex items-center gap-2 bg-red-500/20 text-red-400 px-4 py-2 rounded-full mb-6">
                <ShieldAlert size={18} />
                <span className="font-semibold">RISCOS CRÍTICOS</span>
              </div>
              <h2 className="text-3xl font-bold mb-6">6 Consequências Devastadoras de Não Registrar Sua Marca</h2>
              <p className="text-xl text-gray-400 max-w-3xl mx-auto">
                Estas são as realidades que ninguém conta para você quando abre um negócio. Conhecer estes riscos pode
                salvar sua empresa.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-gray-800 rounded-xl p-8 border border-red-500/20 hover:border-red-500/50 transition-colors">
                <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mb-6">
                  <Ban className="h-8 w-8 text-red-500" />
                </div>
                <h3 className="text-xl font-bold mb-4">Perda Total do Negócio</h3>
                <p className="text-gray-400">
                  Sem o registro, você pode ser obrigado a abandonar sua marca após anos de investimento, perdendo todo
                  o reconhecimento e valor construído.
                </p>
              </div>

              <div className="bg-gray-800 rounded-xl p-8 border border-red-500/20 hover:border-red-500/50 transition-colors">
                <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mb-6">
                  <DollarSign className="h-8 w-8 text-red-500" />
                </div>
                <h3 className="text-xl font-bold mb-4">Indenizações Milionárias</h3>
                <p className="text-gray-400">
                  Usar uma marca já registrada por terceiros pode resultar em processos judiciais com indenizações que
                  ultrapassam R$ 500 mil, além de danos morais.
                </p>
              </div>

              <div className="bg-gray-800 rounded-xl p-8 border border-red-500/20 hover:border-red-500/50 transition-colors">
                <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mb-6">
                  <Trash2 className="h-8 w-8 text-red-500" />
                </div>
                <h3 className="text-xl font-bold mb-4">Destruição de Estoque</h3>
                <p className="text-gray-400">
                  Você pode ser obrigado a destruir todo seu estoque de produtos, embalagens e material publicitário que
                  contenha a marca contestada.
                </p>
              </div>

              <div className="bg-gray-800 rounded-xl p-8 border border-red-500/20 hover:border-red-500/50 transition-colors">
                <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mb-6">
                  <Building className="h-8 w-8 text-red-500" />
                </div>
                <h3 className="text-xl font-bold mb-4">Fechamento de Unidades</h3>
                <p className="text-gray-400">
                  Empresas foram forçadas a fechar filiais inteiras após perderem o direito de usar sua própria marca em
                  determinadas regiões.
                </p>
              </div>

              <div className="bg-gray-800 rounded-xl p-8 border border-red-500/20 hover:border-red-500/50 transition-colors">
                <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mb-6">
                  <Clock className="h-8 w-8 text-red-500" />
                </div>
                <h3 className="text-xl font-bold mb-4">Recomeço do Zero</h3>
                <p className="text-gray-400">
                  Imagine ter que reconstruir sua identidade após 10 anos de mercado, perdendo clientes, reconhecimento
                  e posicionamento.
                </p>
              </div>

              <div className="bg-gray-800 rounded-xl p-8 border border-red-500/20 hover:border-red-500/50 transition-colors">
                <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mb-6">
                  <FileWarning className="h-8 w-8 text-red-500" />
                </div>
                <h3 className="text-xl font-bold mb-4">Bloqueio em Plataformas</h3>
                <p className="text-gray-400">
                  Sem registro, sua marca pode ser removida de marketplaces, redes sociais e aplicativos por denúncias
                  de terceiros.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Statistics Section */}
        <section className="py-20 bg-gradient-to-br from-red-900/40 to-gray-900">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-6">A Realidade em Números</h2>
              <p className="text-xl text-gray-400 max-w-3xl mx-auto">
                Dados que revelam a dimensão do problema e o risco real que sua empresa corre neste momento.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="bg-gray-900/80 rounded-xl p-8 text-center">
                <div className="text-4xl font-bold text-red-500 mb-4">78%</div>
                <p className="text-gray-300">
                  dos empreendedores desconhecem que podem estar infringindo marcas de terceiros
                </p>
              </div>

              <div className="bg-gray-900/80 rounded-xl p-8 text-center">
                <div className="text-4xl font-bold text-red-500 mb-4">R$ 380 mil</div>
                <p className="text-gray-300">é o valor médio de indenizações por uso indevido de marca no Brasil</p>
              </div>

              <div className="bg-gray-900/80 rounded-xl p-8 text-center">
                <div className="text-4xl font-bold text-red-500 mb-4">93%</div>
                <p className="text-gray-300">
                  das empresas que perdem disputas de marca enfrentam queda significativa no faturamento
                </p>
              </div>

              <div className="bg-gray-900/80 rounded-xl p-8 text-center">
                <div className="text-4xl font-bold text-red-500 mb-4">3 anos</div>
                <p className="text-gray-300">
                  é o tempo médio que leva para recuperar a reputação após uma mudança forçada de marca
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Legal Consequences */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-12">
                <div className="inline-flex items-center gap-2 bg-red-500/20 text-red-400 px-4 py-2 rounded-full mb-6">
                  <Gavel size={18} />
                  <span className="font-semibold">CONSEQUÊNCIAS LEGAIS</span>
                </div>
                <h2 className="text-3xl font-bold mb-6">O Que a Lei Reserva Para Quem Infringe Marcas</h2>
                <p className="text-xl text-gray-400">
                  A legislação brasileira é implacável com quem utiliza marcas sem autorização, mesmo que por
                  desconhecimento.
                </p>
              </div>

              <div className="bg-gray-900 rounded-xl p-8 border-l-4 border-red-500 mb-8">
                <h3 className="text-xl font-bold mb-4">Artigo 189 da Lei de Propriedade Industrial (Lei 9.279/96)</h3>
                <p className="text-gray-300 italic mb-4">
                  "Comete crime contra registro de marca quem reproduz, sem autorização do titular, no todo ou em parte,
                  marca registrada, ou imita-a de modo que possa induzir confusão."
                </p>
                <div className="flex items-center gap-3 text-red-400">
                  <AlertTriangle size={18} />
                  <p className="font-semibold">Pena: Detenção de 3 meses a 1 ano, ou multa.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
                <div className="bg-gray-900 rounded-xl p-6">
                  <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                    <Scale className="text-red-500" />
                    Indenizações Civis
                  </h3>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 mt-1">•</span>
                      <span>Danos materiais (lucros cessantes e danos emergentes)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 mt-1">•</span>
                      <span>Danos morais (à imagem e reputação do titular)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 mt-1">•</span>
                      <span>Custos com publicidade corretiva</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 mt-1">•</span>
                      <span>Honorários advocatícios e custas processuais</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-gray-900 rounded-xl p-6">
                  <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                    <Ban className="text-red-500" />
                    Medidas Judiciais
                  </h3>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 mt-1">•</span>
                      <span>Busca e apreensão de produtos e materiais</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 mt-1">•</span>
                      <span>Suspensão imediata do uso da marca (liminar)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 mt-1">•</span>
                      <span>Remoção de conteúdo online e bloqueio de sites</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 mt-1">•</span>
                      <span>Destruição de todos os materiais com a marca</span>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="bg-red-900/30 rounded-xl p-8 border border-red-500/30">
                <h3 className="text-xl font-bold mb-4 text-center">Você sabia?</h3>
                <p className="text-gray-300 text-center">
                  O titular da marca pode solicitar judicialmente que você pague uma indenização equivalente a{" "}
                  <span className="font-bold text-white">10 vezes o valor</span> que seria devido por licenciamento
                  durante todo o período de uso indevido. Para marcas usadas por anos, isso pode significar{" "}
                  <span className="font-bold text-white">milhões de reais</span>.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-20 bg-gray-900">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-6">Perguntas Que Podem Salvar Seu Negócio</h2>
              <p className="text-xl text-gray-400 max-w-3xl mx-auto">
                Respostas diretas para as dúvidas mais comuns — e perigosas — sobre registro de marcas.
              </p>
            </div>

            <div className="max-w-3xl mx-auto space-y-6">
              <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <h3 className="text-xl font-bold mb-3 flex items-start gap-3">
                  <AlertCircle className="text-red-500 shrink-0 mt-1" />
                  <span>Posso perder minha marca mesmo depois de anos usando-a no mercado?</span>
                </h3>
                <p className="text-gray-400 ml-9">
                  Sim, absolutamente. O direito de marca no Brasil é atribuído a quem registra primeiro, não a quem usa
                  primeiro. Existem inúmeros casos de empresas que, após 5, 10 ou até 15 anos de operação, foram
                  obrigadas a abandonar completamente suas marcas porque alguém obteve o registro antes. O tempo de uso
                  não garante proteção legal sem o registro formal no INPI.
                </p>
              </div>

              <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <h3 className="text-xl font-bold mb-3 flex items-start gap-3">
                  <AlertCircle className="text-red-500 shrink-0 mt-1" />
                  <span>Qual o valor das indenizações por uso indevido de marca?</span>
                </h3>
                <p className="text-gray-400 ml-9">
                  As indenizações podem ser devastadoras. A legislação brasileira prevê que o valor pode ser calculado
                  com base nos benefícios que o infrator obteve ou nos prejuízos que o titular sofreu, além de danos
                  morais. Há casos documentados de indenizações que ultrapassam R$ 1 milhão. Além disso, o infrator
                  ainda arca com custas processuais e honorários advocatícios, que podem facilmente ultrapassar R$ 100
                  mil em processos complexos.
                </p>
              </div>

              <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <h3 className="text-xl font-bold mb-3 flex items-start gap-3">
                  <AlertCircle className="text-red-500 shrink-0 mt-1" />
                  <span>Posso ser processado mesmo sem saber que a marca já existia?</span>
                </h3>
                <p className="text-gray-400 ml-9">
                  Sim, o desconhecimento não é defesa válida. A lei brasileira não exige que haja má-fé para
                  caracterizar a infração de marca. Mesmo que você tenha agido de boa-fé e desconhecesse completamente a
                  existência da marca anterior, você ainda pode ser condenado a pagar indenizações, mudar sua marca e
                  destruir todo material que a contenha. O Judiciário brasileiro tem sido rigoroso nesses casos,
                  independentemente da intenção do infrator.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-br from-red-900/40 to-gray-900">
          <div className="container mx-auto px-4 text-center">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Não Espere Receber Uma Notificação Extrajudicial Para Agir
              </h2>
              <p className="text-xl text-gray-300 mb-8">
                O registro de marca custa menos de 1% do valor médio de uma indenização por uso indevido. Proteja seu
                investimento, sua reputação e seu futuro agora.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white font-bold px-8 py-6 text-lg">
                  Proteja Sua Marca Agora
                  <ArrowRight className="ml-2" />
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-white text-white hover:bg-white/10 px-8 py-6 text-lg"
                >
                  Falar Com Especialista
                </Button>
              </div>
              <p className="text-gray-400 mt-6">
                Já ajudamos mais de 2.500 empresas a protegerem suas marcas. Não deixe a sua para depois.
              </p>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}


import { Button } from "@/components/ui/button"
import {
  Search,
  FileText,
  CheckCircle2,
  Clock,
  AlertCircle,
  FileCheck,
  Send,
  Award,
  ArrowRight,
  HelpCircle,
} from "lucide-react"

const timelineSteps = [
  {
    title: "Pesquisa Prévia",
    description: "Análise de viabilidade e busca por marcas similares",
    status: "completed",
    time: "1-2 dias úteis",
    icon: Search,
    details: [
      "Verificação de disponibilidade da marca",
      "Análise de marcas similares",
      "Avaliação de riscos",
      "Relatório detalhado",
    ],
  },
  {
    title: "Preparação da Documentação",
    description: "Organização dos documentos necessários",
    status: "completed",
    time: "2-3 dias úteis",
    icon: FileText,
    details: [
      "Documentos de identificação",
      "Especificação de produtos/serviços",
      "Classificação Nice",
      "Procuração (se necessário)",
    ],
  },
  {
    title: "Depósito do Pedido",
    description: "Protocolo junto ao INPI",
    status: "in-progress",
    time: "24 horas",
    icon: Send,
    details: ["Preenchimento do formulário", "Pagamento das taxas", "Envio da documentação", "Protocolo do pedido"],
  },
  {
    title: "Exame Formal",
    description: "Análise inicial pelo INPI",
    status: "pending",
    time: "60 dias",
    icon: FileCheck,
    details: [
      "Verificação da documentação",
      "Análise dos requisitos formais",
      "Publicação na RPI",
      "Início do prazo de oposição",
    ],
  },
  {
    title: "Período de Oposição",
    description: "Prazo para contestações de terceiros",
    status: "pending",
    time: "60 dias",
    icon: AlertCircle,
    details: [
      "Monitoramento de oposições",
      "Análise de manifestações",
      "Preparação de defesa",
      "Acompanhamento do processo",
    ],
  },
  {
    title: "Exame Técnico",
    description: "Análise substantiva pelo INPI",
    status: "pending",
    time: "11-15 meses",
    icon: HelpCircle,
    details: [
      "Análise de distintividade",
      "Verificação de colidência",
      "Exame dos requisitos legais",
      "Decisão de deferimento/indeferimento",
    ],
  },
  {
    title: "Concessão do Registro",
    description: "Expedição do certificado",
    status: "pending",
    time: "60 dias após pagamento",
    icon: Award,
    details: [
      "Pagamento da taxa final",
      "Expedição do certificado",
      "Registro por 10 anos",
      "Direito de uso exclusivo",
    ],
  },
]

export default function ProcessoPage() {
  return (
    <div className="flex flex-col min-h-screen bg-background text-white">
      <main className="flex-grow">
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-12">
              <h1 className="text-4xl font-bold mb-4">Como Funciona o Processo de Registro</h1>
              <p className="text-xl text-gray-400">
                Conheça cada etapa do processo de registro de marca e acompanhe o progresso do seu pedido
              </p>
            </div>

            <div className="max-w-4xl mx-auto">
              <div className="relative">
                {/* Timeline line */}
                <div className="absolute left-[2.4rem] top-0 h-full w-px bg-gray-800 md:left-1/2 md:-ml-[2px]" />

                {timelineSteps.map((step, index) => (
                  <div key={index} className="relative mb-12">
                    <div
                      className={`flex flex-col items-start gap-6 md:flex-row ${
                        index % 2 === 0 ? "md:flex-row-reverse" : ""
                      }`}
                    >
                      {/* Timeline node */}
                      <div className="absolute left-0 flex h-12 w-12 items-center justify-center md:left-1/2 md:-ml-6">
                        <div
                          className={`flex h-12 w-12 items-center justify-center rounded-full border-2 ${
                            step.status === "completed"
                              ? "border-green-500 bg-green-500 text-white"
                              : step.status === "in-progress"
                                ? "border-primary bg-primary/20 text-primary"
                                : [
                                      "Exame Formal",
                                      "Período de Oposição",
                                      "Exame Técnico",
                                      "Concessão do Registro",
                                    ].includes(step.title)
                                  ? "border-blue-500 bg-blue-500/20 text-blue-500"
                                  : "border-gray-700 bg-gray-900 text-gray-400"
                          }`}
                        >
                          {step.icon && <step.icon className="h-5 w-5" />}
                        </div>
                      </div>

                      {/* Content */}
                      <div
                        className={`ml-20 w-full md:ml-0 md:w-[calc(50%-3rem)] ${
                          index % 2 === 0 ? "md:pr-16" : "md:pl-16"
                        }`}
                      >
                        <div className="rounded-xl bg-gray-900 p-6">
                          <div className="mb-4 flex items-center justify-between">
                            <h3 className="text-xl font-bold">{step.title}</h3>
                            <div
                              className={`flex items-center gap-2 rounded-full px-3 py-1 text-sm ${
                                step.status === "completed"
                                  ? "bg-green-500/20 text-green-500"
                                  : step.status === "in-progress"
                                    ? "bg-primary/20 text-primary"
                                    : [
                                          "Exame Formal",
                                          "Período de Oposição",
                                          "Exame Técnico",
                                          "Concessão do Registro",
                                        ].includes(step.title)
                                      ? "bg-blue-500/20 text-blue-500"
                                      : "bg-gray-800 text-gray-400"
                              }`}
                            >
                              <Clock className="h-4 w-4" />
                              <span>{step.time}</span>
                            </div>
                          </div>
                          <p className="mb-4 text-gray-400">{step.description}</p>
                          <ul className="grid gap-2">
                            {step.details.map((detail, detailIndex) => (
                              <li key={detailIndex} className="flex items-center gap-2">
                                <CheckCircle2
                                  className={`h-4 w-4 ${
                                    step.status === "completed"
                                      ? "text-green-500"
                                      : step.status === "in-progress"
                                        ? "text-primary"
                                        : [
                                              "Exame Formal",
                                              "Período de Oposição",
                                              "Exame Técnico",
                                              "Concessão do Registro",
                                            ].includes(step.title)
                                          ? "text-blue-500"
                                          : "text-gray-600"
                                  }`}
                                />
                                <span className="text-sm text-gray-300">{detail}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-900">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl font-bold mb-6">Pronto para Iniciar seu Processo?</h2>
              <p className="text-gray-400 mb-8">
                Conte com nossa experiência para garantir um processo de registro tranquilo e eficiente. Solicite agora
                uma análise gratuita da sua marca.
              </p>
              <Button className="bg-gradient-to-r from-primary to-secondary text-lg px-8 py-6">
                Iniciar Processo
                <ArrowRight className="ml-2" />
              </Button>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}


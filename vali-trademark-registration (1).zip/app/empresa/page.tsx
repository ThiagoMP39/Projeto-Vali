import { Button } from "@/components/ui/button"
import { Users, Target, Clock, Award, Briefcase, CheckCircle2 } from "lucide-react"
import Image from "next/image"

const teamMembers = [
  {
    name: "Roberto Silva",
    role: "CEO & Fundador",
    bio: "Especialista em Propriedade Intelectual com mais de 15 anos de experiência no mercado.",
    avatar: "/placeholder.svg?height=300&width=300",
  },
  {
    name: "Ana Oliveira",
    role: "Diretora Jurídica",
    bio: "Advogada especializada em Direito Marcário e Propriedade Intelectual.",
    avatar: "/placeholder.svg?height=300&width=300",
  },
  {
    name: "Carlos Santos",
    role: "Gerente de Operações",
    bio: "Responsável por garantir a excelência e agilidade em todos os processos.",
    avatar: "/placeholder.svg?height=300&width=300",
  },
]

const values = [
  {
    icon: Users,
    title: "Foco no Cliente",
    description: "Comprometimento total com a satisfação e sucesso dos nossos clientes.",
  },
  {
    icon: Target,
    title: "Excelência",
    description: "Busca constante pela qualidade e aperfeiçoamento dos nossos serviços.",
  },
  {
    icon: Clock,
    title: "Agilidade",
    description: "Processos otimizados para garantir rapidez sem perder a qualidade.",
  },
  {
    icon: Award,
    title: "Credibilidade",
    description: "Transparência e confiança em todas as nossas relações.",
  },
]

export default function CompanyPage() {
  return (
    <div className="flex flex-col min-h-screen bg-background text-white">
      <main className="flex-grow">
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <h1 className="text-4xl font-bold mb-6">Nossa História</h1>
              <p className="text-xl text-gray-400">
                Desde 2020, a VALI tem se dedicado a simplificar e agilizar o processo de registro de marcas no Brasil,
                ajudando empresas a protegerem seus ativos mais valiosos.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <Image
                  src="/placeholder.svg?height=400&width=600"
                  width={600}
                  height={400}
                  alt="VALI Office"
                  className="rounded-xl"
                />
              </div>
              <div>
                <h2 className="text-2xl font-bold mb-6">Uma Nova Era no Registro de Marcas</h2>
                <p className="text-gray-400 mb-6">
                  A VALI nasceu da visão de transformar o complexo processo de registro de marcas em algo simples e
                  acessível. Nossa jornada começou com o compromisso de unir tecnologia e expertise jurídica para
                  oferecer um serviço diferenciado.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="text-primary" />
                    <span>Mais de 2500 marcas registradas com sucesso</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="text-primary" />
                    <span>100% de satisfação dos clientes</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="text-primary" />
                    <span>Presente em todo território nacional</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-gray-900">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Nossos Valores</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {values.map((value, index) => (
                <div key={index} className="text-center">
                  <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center">
                    <value.icon size={32} className="text-white" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                  <p className="text-gray-400">{value.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-background">Nossa Equipe</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {teamMembers.map((member, index) => (
                <div key={index} className="bg-gray-900 rounded-xl p-6 text-center">
                  <Image
                    src={member.avatar || "/placeholder.svg"}
                    width={200}
                    height={200}
                    alt={member.name}
                    className="rounded-full mx-auto mb-4 w-48 h-48 object-cover"
                  />
                  <h3 className="text-xl font-semibold mb-2 text-white">{member.name}</h3>
                  <p className="text-primary mb-2">{member.role}</p>
                  <p className="text-gray-400">{member.bio}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 bg-gray-900 text-white">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-3xl font-bold text-center mb-8">Nossa Missão</h2>
              <p className="text-xl text-gray-400 text-center mb-12">
                Simplificar e democratizar o acesso ao registro de marcas, garantindo a proteção e o sucesso dos nossos
                clientes através de um serviço ágil, transparente e de qualidade.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-background p-6 rounded-xl">
                  <Briefcase className="w-12 h-12 text-primary mb-4" />
                  <h3 className="text-xl font-semibold mb-2">Experiência</h3>
                  <p className="text-gray-400">
                    Nossa equipe combina décadas de experiência em propriedade intelectual com uma abordagem moderna e
                    tecnológica.
                  </p>
                </div>
                <div className="bg-background p-6 rounded-xl">
                  <Target className="w-12 h-12 text-primary mb-4" />
                  <h3 className="text-xl font-semibold mb-2">Compromisso</h3>
                  <p className="text-gray-400">
                    Comprometidos em entregar resultados excepcionais e superar as expectativas dos nossos clientes.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-8">Faça Parte da Nossa História</h2>
            <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
              Junte-se aos milhares de clientes que já confiam na VALI para proteger suas marcas
            </p>
            <Button className="bg-gradient-to-r from-primary to-secondary text-white hover:opacity-90 text-lg px-8 py-6">
              Entre em Contato
            </Button>
          </div>
        </section>
      </main>
    </div>
  )
}


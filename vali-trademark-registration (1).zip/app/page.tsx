import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  MessageCircle,
  Search,
  FileText,
  CheckCircle,
  Shield,
  TrendingUp,
  Award,
  CheckCircle2,
  Star,
} from "lucide-react"
import Image from "next/image"
import { AnimatedSection } from "@/components/animated-section"
import { AnimatedIcon } from "@/components/animated-icon"
import { AnimatedList } from "@/components/animated-list"

const testimonials = [
  {
    name: "Maria Silva",
    company: "Boutique Fashion",
    text: "O processo foi muito mais simples do que eu imaginava. A equipe da VALI me auxiliou em cada etapa e conseguimos o registro da nossa marca com sucesso!",
    avatar: "/placeholder.svg?height=60&width=60",
  },
  {
    name: "João Santos",
    company: "Tech Solutions",
    text: "Profissionalismo e agilidade são as palavras que definem a VALI. Recomendo para todos que precisam registrar sua marca.",
    avatar: "/placeholder.svg?height=60&width=60",
  },
  {
    name: "Ana Costa",
    company: "Café Especial",
    text: "Excelente atendimento e suporte durante todo o processo. Muito satisfeita com o resultado final!",
    avatar: "/placeholder.svg?height=60&width=60",
  },
]

const faqs = [
  {
    question: "Quanto tempo leva para registrar uma marca?",
    answer:
      "O processo completo de registro de marca no INPI pode levar em média de 11 a 15 meses. No entanto, com a VALI, seu pedido é protocolado em até 24 horas após o envio da documentação necessária.",
  },
  {
    question: "Qual o custo para registrar uma marca?",
    answer:
      "A VALI trás o preço mais acessível de todo mercado, para que qualquer pessoa consiga registrar sua marca. O investimento varia de acordo com as classes que deseja proteger. Entre em contato conosco para uma avaliação personalizada.",
  },
  {
    question: "Por que devo registrar minha marca?",
    answer:
      "O registro garante exclusividade sobre sua marca em todo território nacional, previne uso indevido por terceiros, aumenta o valor do seu negócio e proporciona mais segurança jurídica.",
  },
  {
    question: "Preciso de um CNPJ para registrar uma marca?",
    answer:
      "Não é obrigatório ter um CNPJ para registrar uma marca. Pessoas físicas também podem solicitar o registro em seu próprio nome.",
  },
]

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen bg-background text-white">
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="py-12 md:py-20 relative">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <AnimatedSection variant="fadeInLeft" className="md:w-1/2 mb-10 md:mb-0">
                <h1 className="text-3xl md:text-5xl font-bold mb-6 leading-tight">
                  Proteja Seu Negócio com a VALI Registro de Marcas
                </h1>
                <p className="text-lg md:text-xl mb-8 text-gray-300">
                  Garanta a Proteção da Sua Marca no Brasil. Evite complicações futuras com o registro completo e
                  descomplicado de sua marca.
                </p>
                <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                  <Button className="bg-gradient-to-r from-primary to-secondary text-white hover:opacity-90 w-full sm:w-auto">
                    Comece Agora
                  </Button>
                  <Button variant="outline" className="border-white text-white hover:bg-white/10 w-full sm:w-auto">
                    Tirar dúvidas
                  </Button>
                </div>
              </AnimatedSection>
              <AnimatedSection variant="fadeInRight" className="w-full md:w-5/12">
                <div className="bg-gradient-to-br from-primary to-secondary p-1 rounded-2xl">
                  <div className="bg-white rounded-2xl p-6">
                    <h2 className="text-xl md:text-2xl font-bold text-gray-800 mb-2">Inicie seu registro de marca</h2>
                    <p className="text-gray-600 mb-6">
                      Preencha seus dados e receba um atendimento personalizado para proteger a sua marca
                    </p>
                    <form className="space-y-4">
                      <Input placeholder="Digite seu nome" className="bg-gray-50" />
                      <Input type="email" placeholder="Digite seu e-mail" className="bg-gray-50" />
                      <Input placeholder="Nome da sua empresa" className="bg-gray-50" />
                      <Input placeholder="(XX) XXXXX-XXXX" className="bg-gray-50" />
                      <Button className="w-full bg-gradient-to-r from-[#00E676] to-[#00B8D4] text-white hover:opacity-90">
                        Enviar
                      </Button>
                    </form>
                  </div>
                </div>
              </AnimatedSection>
            </div>
          </div>
        </section>

        {/* Process Section */}
        <section className="py-12 md:py-16 bg-gray-900">
          <div className="container mx-auto px-4">
            <AnimatedSection variant="fadeIn" className="text-center mb-12">
              <p className="text-lg md:text-xl">
                Garanta seu pedido de registro de marca em <span className="text-green-500 font-bold">24 horas</span>{" "}
                seguindo nosso guia simplificado de apenas <span className="text-green-500 font-bold">4 passos</span>.
              </p>
            </AnimatedSection>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
              <AnimatedSection variant="fadeInUp" delay={0.1}>
                <div className="text-center">
                  <AnimatedIcon
                    variant="pulse"
                    className="w-16 h-16 md:w-20 md:h-20 mx-auto mb-4 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center"
                  >
                    <MessageCircle size={24} className="text-white" />
                  </AnimatedIcon>
                  <h3 className="text-lg md:text-xl font-semibold mb-2">Contato inicial</h3>
                  <p className="text-green-500">Entre em contato conosco para iniciar o processo</p>
                </div>
              </AnimatedSection>
              <AnimatedSection variant="fadeInUp" delay={0.2}>
                <div className="text-center">
                  <AnimatedIcon
                    variant="pulse"
                    className="w-16 h-16 md:w-20 md:h-20 mx-auto mb-4 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center"
                  >
                    <Search size={24} className="text-white" />
                  </AnimatedIcon>
                  <h3 className="text-lg md:text-xl font-semibold mb-2">Estudo de viabilidade</h3>
                  <p className="text-green-500">Análise detalhada da sua marca</p>
                </div>
              </AnimatedSection>
              <AnimatedSection variant="fadeInUp" delay={0.3}>
                <div className="text-center">
                  <AnimatedIcon
                    variant="pulse"
                    className="w-16 h-16 md:w-20 md:h-20 mx-auto mb-4 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center"
                  >
                    <FileText size={24} className="text-white" />
                  </AnimatedIcon>
                  <h3 className="text-lg md:text-xl font-semibold mb-2">Envio da documentação</h3>
                  <p className="text-green-500">Preparação e envio dos documentos necessários</p>
                </div>
              </AnimatedSection>
              <AnimatedSection variant="fadeInUp" delay={0.4}>
                <div className="text-center">
                  <AnimatedIcon
                    variant="pulse"
                    className="w-16 h-16 md:w-20 md:h-20 mx-auto mb-4 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center"
                  >
                    <CheckCircle size={24} className="text-white" />
                  </AnimatedIcon>
                  <h3 className="text-lg md:text-xl font-semibold mb-2">Pedido de Registro</h3>
                  <p className="text-green-500">Finalização e protocolo do pedido</p>
                </div>
              </AnimatedSection>
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-12 md:py-20 bg-white text-background">
          <div className="container mx-auto px-4">
            <AnimatedSection variant="fadeIn" className="text-center mb-12">
              <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">
                Por que Registrar Sua Marca é Crucial?
              </h2>
            </AnimatedSection>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <AnimatedSection variant="fadeInUp" delay={0.1}>
                <div className="bg-gray-900 p-6 md:p-8 rounded-xl">
                  <AnimatedIcon
                    variant="bounce"
                    className="w-14 h-14 md:w-16 md:h-16 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center mb-6"
                  >
                    <Shield className="w-6 h-6 md:w-8 md:h-8 text-white" />
                  </AnimatedIcon>
                  <h3 className="text-lg md:text-xl font-semibold mb-4 text-gold">Proteção Legal</h3>
                  <p className="text-white">
                    Garanta exclusividade sobre sua marca em todo território nacional e evite uso indevido por
                    terceiros.
                  </p>
                </div>
              </AnimatedSection>
              <AnimatedSection variant="fadeInUp" delay={0.2}>
                <div className="bg-gray-900 p-6 md:p-8 rounded-xl">
                  <AnimatedIcon
                    variant="bounce"
                    className="w-14 h-14 md:w-16 md:h-16 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center mb-6"
                  >
                    <TrendingUp className="w-6 h-6 md:w-8 md:h-8 text-white" />
                  </AnimatedIcon>
                  <h3 className="text-lg md:text-xl font-semibold mb-4 text-gold">Valor do Negócio</h3>
                  <p className="text-white">
                    Aumente o valor do seu negócio e fortaleça sua presença no mercado com uma marca registrada.
                  </p>
                </div>
              </AnimatedSection>
              <AnimatedSection variant="fadeInUp" delay={0.3}>
                <div className="bg-gray-900 p-6 md:p-8 rounded-xl">
                  <AnimatedIcon
                    variant="bounce"
                    className="w-14 h-14 md:w-16 md:h-16 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center mb-6"
                  >
                    <Award className="w-6 h-6 md:w-8 md:h-8 text-white" />
                  </AnimatedIcon>
                  <h3 className="text-lg md:text-xl font-semibold mb-4 text-gold">Credibilidade</h3>
                  <p className="text-white">
                    Transmita mais confiança aos seus clientes e parceiros com uma marca oficialmente registrada.
                  </p>
                </div>
              </AnimatedSection>
            </div>
          </div>
        </section>

        {/* Company Introduction Section */}
        <section className="py-12 md:py-20 bg-gray-900">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12">
              <AnimatedSection variant="fadeInLeft" className="w-full md:w-1/2">
                <h2 className="text-2xl md:text-3xl font-bold mb-6">
                  Conheça a VALI: Líder em Registro de Marcas desde 2020
                </h2>
                <p className="text-gray-400 mb-6">
                  Com anos de experiência no mercado, a VALI se destaca pela excelência no processo de registro de
                  marcas, oferecendo um serviço completo e personalizado para cada cliente.
                </p>
                <AnimatedList staggerDelay={0.1} variant="fadeInLeft">
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="text-blue-500 flex-shrink-0" />
                    <span>
                      Mais de <span className="text-blue-500">2500</span> marcas registradas com sucesso
                    </span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="text-blue-500 flex-shrink-0" />
                    <span>Equipe especializada em propriedade intelectual</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="text-blue-500 flex-shrink-0" />
                    <span>Processo 100% digital e descomplicado</span>
                  </li>
                </AnimatedList>
              </AnimatedSection>
              <AnimatedSection variant="fadeInRight" className="w-full md:w-1/2 mt-8 md:mt-0">
                <Image
                  src="/placeholder.svg?height=400&width=600"
                  width={600}
                  height={400}
                  alt="Equipe VALI"
                  className="rounded-xl w-full h-auto"
                />
              </AnimatedSection>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-12 md:py-20 bg-white text-background">
          <div className="container mx-auto px-4 text-center">
            <AnimatedSection variant="fadeInUp">
              <h2 className="text-2xl md:text-3xl font-bold mb-6 md:mb-8">
                Descubra agora se sua marca está registrada
              </h2>
              <p className="text-gray-400 mb-6 md:mb-8 max-w-2xl mx-auto">
                Faça uma pesquisa rápida e gratuita para verificar a disponibilidade da sua marca no mercado.
              </p>
              <Button className="bg-gradient-to-r from-primary to-secondary text-white hover:opacity-90 text-base md:text-lg px-6 py-3 md:px-8 md:py-6">
                Pesquisar Agora
              </Button>
            </AnimatedSection>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="py-12 md:py-20 bg-gray-900">
          <div className="container mx-auto px-4">
            <AnimatedSection variant="fadeIn" className="text-center mb-8 md:mb-12">
              <h2 className="text-2xl md:text-3xl font-bold text-center mb-8 md:mb-12">
                Quem já experimentou a VALI, indica
              </h2>
            </AnimatedSection>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {testimonials.map((testimonial, index) => (
                <div key={index} className="bg-gray-800 p-6 rounded-xl h-full flex flex-col">
                  <div className="flex items-center gap-4 mb-4">
                    <Image
                      src={testimonial.avatar || "/placeholder.svg"}
                      width={60}
                      height={60}
                      alt={testimonial.name}
                      className="rounded-full w-12 h-12 object-cover"
                    />
                    <div>
                      <h3 className="font-semibold text-base">{testimonial.name}</h3>
                      <p className="text-gray-400 text-sm">{testimonial.company}</p>
                    </div>
                  </div>
                  <p className="text-gray-300 text-sm flex-grow mb-4">{testimonial.text}</p>
                  <div className="flex gap-1 mt-auto">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <AnimatedIcon key={star} variant="scale" delay={index * 0.1 + star * 0.05}>
                        <Star className="text-yellow-400 fill-yellow-400 w-4 h-4" />
                      </AnimatedIcon>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-12 md:py-20">
          <div className="container mx-auto px-4">
            <AnimatedSection variant="fadeIn" className="text-center mb-8 md:mb-12">
              <h2 className="text-2xl md:text-3xl font-bold text-center mb-8 md:mb-12">
                Tire Suas Dúvidas sobre Registro de Marca
              </h2>
            </AnimatedSection>
            <div className="max-w-3xl mx-auto space-y-4 md:space-y-6">
              <AnimatedList staggerDelay={0.15} variant="fadeInUp">
                {faqs.map((faq, index) => (
                  <div key={index} className="bg-gray-900 rounded-xl p-5 md:p-6">
                    <h3 className="text-lg md:text-xl font-semibold mb-2 md:mb-3">{faq.question}</h3>
                    <p className="text-gray-400 text-sm md:text-base">{faq.answer}</p>
                  </div>
                ))}
              </AnimatedList>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}


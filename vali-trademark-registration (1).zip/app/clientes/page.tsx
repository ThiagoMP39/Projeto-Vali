import { Button } from "@/components/ui/button"
import { Star, Building2, Users2, Globe2, CheckCircle2 } from "lucide-react"
import Image from "next/image"

const successCases = [
  {
    name: "João e Maria Santos",
    segment: "Confeitaria Artesanal",
    logo: "/placeholder.svg?height=100&width=100",
    description:
      "Começaram fazendo bolos em casa para complementar a renda. Quando o negócio cresceu, descobriram que alguém estava usando o mesmo nome em outra cidade. A VALI garantiu o registro prioritário em 12 meses.",
    result: "Hoje possuem 3 lojas próprias",
  },
  {
    name: "Pedro Oliveira",
    segment: "Desenvolvedor de Apps",
    logo: "/placeholder.svg?height=100&width=100",
    description:
      "Criou um app de sucesso, mas enfrentou problemas com cópias no exterior. Com nossa ajuda, conseguiu proteção internacional via Protocolo de Madri antes que fosse tarde.",
    result: "App protegido em 12 países",
  },
  {
    name: "Ana Carolina Lima",
    segment: "Moda Sustentável",
    logo: "/placeholder.svg?height=100&width=100",
    description:
      "Sua marca de roupas sustentáveis estava crescendo quando encontrou produtos falsificados online. Realizamos o registro emergencial e removemos todos os anúncios irregulares.",
    result: "Marca 100% protegida online",
  },
  {
    name: "Roberto e Júlia Mendes",
    segment: "Escola de Idiomas",
    logo: "/placeholder.svg?height=100&width=100",
    description:
      "O casal construiu uma metodologia única de ensino, mas recebeu oposição ao registro da marca. Nossa equipe desenvolveu defesa que garantiu seus direitos.",
    result: "Metodologia registrada com sucesso",
  },
  {
    name: "Fernanda Costa",
    segment: "Produtos Naturais",
    logo: "/placeholder.svg?height=100&width=100",
    description:
      "Começou vendendo cosméticos naturais em feiras. Quando quis expandir, descobriu marca similar. Negociamos acordo que permitiu o registro com adaptações.",
    result: "Expansão nacional garantida",
  },
  {
    name: "Lucas Martins",
    segment: "Personal Trainer",
    logo: "/placeholder.svg?height=100&width=100",
    description:
      "Desenvolveu método próprio de treino e queria proteger antes de franquear. Realizamos registro em múltiplas classes, incluindo materiais didáticos e apps.",
    result: "15 unidades franqueadas",
  },
]

const testimonials = [
  {
    name: "Marina Rodrigues",
    role: "Empreendedora",
    segment: "Moda Infantil",
    text: "Hesitei muito em registrar minha marca no início, achava complexo e caro. A VALI me mostrou que era mais simples do que imaginava. Hoje tenho minha marca protegida e durmo tranquila!",
    avatar: "/placeholder.svg?height=80&width=80",
    rating: 5,
  },
  {
    name: "Rafael Almeida",
    role: "Empreendedor",
    segment: "Tecnologia",
    text: "A equipe da VALI foi incrivelmente atenciosa. Me explicaram cada passo do processo e resolveram rapidamente quando surgiu uma oposição ao meu pedido de registro.",
    avatar: "/placeholder.svg?height=80&width=80",
    rating: 5,
  },
  {
    name: "Beatriz Santos",
    role: "Empreendedora",
    segment: "Gastronomia",
    text: "Comecei pequena, mas a VALI me tratou como uma grande empresa. Hoje minha marca está protegida e consigo focar no crescimento do negócio sem preocupações.",
    avatar: "/placeholder.svg?height=80&width=80",
    rating: 5,
  },
]

const clientLogos = Array(12).fill("/placeholder.svg?height=80&width=80")

export default function ClientsPage() {
  return (
    <div className="flex flex-col min-h-screen bg-background text-white">
      <main className="flex-grow">
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <h1 className="text-4xl font-bold mb-6">Histórias Reais de Empreendedores</h1>
              <p className="text-xl text-gray-400">
                Conheça como ajudamos empreendedores a transformarem seus sonhos em marcas protegidas e reconhecidas no
                mercado
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
              {successCases.map((case_, index) => (
                <div key={index} className="bg-gray-900 rounded-xl p-8">
                  <div className="flex items-center gap-4 mb-6">
                    <Image
                      src={case_.logo || "/placeholder.svg"}
                      width={60}
                      height={60}
                      alt={case_.name}
                      className="rounded-full"
                    />
                    <div>
                      <h3 className="font-semibold text-xl">{case_.name}</h3>
                      <p className="text-gray-400">{case_.segment}</p>
                    </div>
                  </div>
                  <p className="text-gray-300 mb-4">{case_.description}</p>
                  <div className="bg-gradient-to-r from-primary to-secondary p-[1px] rounded-lg">
                    <div className="bg-gray-900 rounded-lg p-4">
                      <p className="font-semibold text-center">{case_.result}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-16">
              <div className="bg-gray-900 p-8 rounded-xl text-center">
                <Building2 className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="text-3xl font-bold mb-2">2500+</h3>
                <p className="text-gray-400">Marcas Registradas</p>
              </div>
              <div className="bg-gray-900 p-8 rounded-xl text-center">
                <Users2 className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="text-3xl font-bold mb-2">100%</h3>
                <p className="text-gray-400">Satisfação dos Clientes</p>
              </div>
              <div className="bg-gray-900 p-8 rounded-xl text-center">
                <Globe2 className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="text-3xl font-bold mb-2">27</h3>
                <p className="text-gray-400">Estados Atendidos</p>
              </div>
              <div className="bg-gray-900 p-8 rounded-xl text-center">
                <CheckCircle2 className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="text-3xl font-bold mb-2">99%</h3>
                <p className="text-gray-400">Taxa de Aprovação</p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-white text-background">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">O Que Nossos Clientes Dizem</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <div key={index} className="bg-background p-6 rounded-xl">
                  <div className="flex items-center gap-4 mb-4">
                    <Image
                      src={testimonial.avatar || "/placeholder.svg"}
                      width={60}
                      height={60}
                      alt={testimonial.name}
                      className="rounded-full"
                    />
                    <div>
                      <h3 className="font-semibold text-white">{testimonial.name}</h3>
                      <p className="text-gray-400">{testimonial.role}</p>
                      <p className="text-primary">{testimonial.segment}</p>
                    </div>
                  </div>
                  <p className="text-gray-300 mb-4">{testimonial.text}</p>
                  <div className="flex gap-1">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="text-yellow-400 fill-yellow-400 w-5 h-5" />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Empresas que Confiam na VALI</h2>
            <div className="grid grid-cols-2 md:grid-cols-6 gap-8">
              {clientLogos.map((logo, index) => (
                <div key={index} className="bg-gray-900 p-4 rounded-xl flex items-center justify-center">
                  <Image
                    src={logo || "/placeholder.svg"}
                    width={80}
                    height={80}
                    alt={`Cliente ${index + 1}`}
                    className="opacity-75 hover:opacity-100 transition-opacity"
                  />
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 bg-gray-900">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-8">Pronto para Proteger sua Marca?</h2>
            <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
              Junte-se às milhares de empresas que já garantiram a proteção de suas marcas com a VALI
            </p>
            <Button className="bg-gradient-to-r from-primary to-secondary text-white hover:opacity-90 text-lg px-8 py-6">
              Comece Agora
            </Button>
          </div>
        </section>
      </main>
    </div>
  )
}


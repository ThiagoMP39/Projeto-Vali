"use client"

import type React from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Facebook, Instagram, MessageCircle, Menu, X } from "lucide-react"
import { RegistrationNotification } from "@/components/registration-notification"
import { ScrollToTop } from "@/components/scroll-to-top"
import { useState } from "react"
import { Inter } from "next/font/google"

const inter = Inter({ subsets: ["latin"] })

function MobileNav() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="md:hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="text-background hover:text-primary transition-colors"
        aria-label={isOpen ? "Fechar menu" : "Abrir menu"}
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {isOpen && (
        <div className="absolute top-16 left-0 right-0 bg-white z-50 border-b border-gray-200 shadow-lg">
          <nav className="container mx-auto px-4 py-4">
            <ul className="flex flex-col space-y-4">
              <li>
                <Link
                  href="/"
                  className="text-background hover:text-primary transition-colors block py-2"
                  onClick={() => setIsOpen(false)}
                >
                  VALI
                </Link>
              </li>
              <li>
                <Link
                  href="/nossos-servicos"
                  className="text-background hover:text-primary transition-colors block py-2"
                  onClick={() => setIsOpen(false)}
                >
                  Nossos serviços
                </Link>
              </li>
              <li>
                <Link
                  href="/empresa"
                  className="text-background hover:text-primary transition-colors block py-2"
                  onClick={() => setIsOpen(false)}
                >
                  Empresa
                </Link>
              </li>
              <li>
                <Link
                  href="/clientes"
                  className="text-background hover:text-primary transition-colors block py-2"
                  onClick={() => setIsOpen(false)}
                >
                  Clientes
                </Link>
              </li>
              <li>
                <Link
                  href="/blog"
                  className="text-background hover:text-primary transition-colors block py-2"
                  onClick={() => setIsOpen(false)}
                >
                  Blog
                </Link>
              </li>
              <li>
                <Link
                  href="/processo"
                  className="text-background hover:text-primary transition-colors block py-2"
                  onClick={() => setIsOpen(false)}
                >
                  Processo
                </Link>
              </li>
              <li>
                <Link
                  href="/educativo"
                  className="text-background hover:text-primary transition-colors block py-2"
                  onClick={() => setIsOpen(false)}
                >
                  Educativo
                </Link>
              </li>
              <li className="pt-2">
                <Button
                  className="bg-gradient-to-r from-primary to-secondary text-white hover:opacity-90 w-full"
                  onClick={() => setIsOpen(false)}
                >
                  Contato
                </Button>
              </li>
            </ul>
          </nav>
        </div>
      )}
    </div>
  )
}

export function ClientLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className={inter.className}>
        <div className="flex flex-col min-h-screen bg-background text-white">
          {/* Adiciona o componente ScrollToTop aqui */}
          <ScrollToTop />

          <header className="border-b border-gray-800 bg-white sticky top-0 z-50">
            <div className="container mx-auto px-4 py-4 flex justify-between items-center">
              <Link href="/">
                <Image
                  src="/placeholder.svg?height=50&width=150"
                  height={50}
                  width={150}
                  alt="VALI Logo"
                  className="h-8 md:h-12 w-auto"
                />
              </Link>
              <nav className="hidden md:block">
                <ul className="flex space-x-6">
                  <li>
                    <Link href="/" className="text-background hover:text-primary transition-colors">
                      VALI
                    </Link>
                  </li>
                  <li>
                    <Link href="/nossos-servicos" className="text-background hover:text-primary transition-colors">
                      Nossos serviços
                    </Link>
                  </li>
                  <li>
                    <Link href="/empresa" className="text-background hover:text-primary transition-colors">
                      Empresa
                    </Link>
                  </li>
                  <li>
                    <Link href="/clientes" className="text-background hover:text-primary transition-colors">
                      Clientes
                    </Link>
                  </li>
                  <li>
                    <Link href="/blog" className="text-background hover:text-primary transition-colors">
                      Blog
                    </Link>
                  </li>
                  <li>
                    <Link href="/processo" className="text-background hover:text-primary transition-colors">
                      Processo
                    </Link>
                  </li>
                  <li>
                    <Link href="/educativo" className="text-background hover:text-primary transition-colors">
                      Educativo
                    </Link>
                  </li>
                </ul>
              </nav>
              <div className="hidden md:block">
                <Button className="bg-gradient-to-r from-primary to-secondary text-white hover:opacity-90">
                  Contato
                </Button>
              </div>
              <MobileNav />
            </div>
          </header>
          <main className="flex-grow">{children}</main>
          <footer className="bg-white text-background py-10">
            <div className="container mx-auto px-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div>
                  <Image
                    src="/placeholder.svg?height=50&width=150"
                    height={50}
                    width={150}
                    alt="VALI Logo"
                    className="mb-4 h-8 md:h-12 w-auto"
                  />
                  <p className="text-sm text-gray-600">
                    <span className="text-green-500">✓</span> Processo 100% online
                    <br />
                    <span className="text-green-500">✓</span> Valor justo
                    <br />
                    <span className="text-green-500">✓</span> Qualidade e praticidade
                    <br />
                    <span className="text-green-500">✓</span> Atendimento agilizado
                    <br />
                    <span className="text-green-500">✓</span> Total transparência
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-4 text-gold">Fale conosco</h3>
                  <div className="flex space-x-4 mb-4">
                    <Facebook className="text-gray-600 hover:text-primary cursor-pointer" />
                    <MessageCircle className="text-gray-600 hover:text-primary cursor-pointer" />
                    <Instagram className="text-gray-600 hover:text-primary cursor-pointer" />
                  </div>
                  <p className="text-sm text-gray-600">
                    Segunda à Sexta, das 08:30h às 18:30h
                    <br />
                    contato@valiregistrodemarcas.com.br
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-2">Empresa Credenciada ao INPI</p>
                  <div className="bg-green-500 p-2 rounded-lg inline-block">
                    <Image
                      src="/placeholder.svg?height=50&width=100"
                      height={50}
                      width={100}
                      alt="INPI Logo"
                      className="h-8 md:h-12 w-auto"
                    />
                  </div>
                </div>
              </div>
            </div>
          </footer>

          {/* Notification de registros recentes */}
          <RegistrationNotification />
        </div>
      </body>
    </html>
  )
}


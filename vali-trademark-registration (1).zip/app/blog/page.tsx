import { Button } from "@/components/ui/button"
import { Search, Clock, User2, ChevronRight } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

const posts = [
  {
    slug: "entenda-nova-lei-propriedade-industrial",
    title: "Entenda a Nova Lei da Propriedade Industrial",
    excerpt:
      "Uma análise completa das mudanças recentes na legislação de propriedade industrial e como elas afetam o registro de marcas no Brasil.",
    image: "/placeholder.svg?height=300&width=600",
    author: "Dra. Patricia Mendes",
    date: "14 de Fevereiro de 2024",
    readTime: "8 min de leitura",
    featured: true,
  },
  {
    slug: "direitos-deveres-titular-marca",
    title: "Direitos e Deveres do Titular de Marca",
    excerpt: "Conheça todos os direitos que você adquire ao registrar uma marca e suas responsabilidades legais.",
    image: "/placeholder.svg?height=200&width=300",
    author: "Dr. Roberto Alves",
    date: "11 de Fevereiro de 2024",
    readTime: "7 min de leitura",
  },
  {
    slug: "como-proceder-violacao-marca",
    title: "Como Proceder em Caso de Violação de Marca",
    excerpt: "Guia legal sobre as medidas a serem tomadas quando sua marca é usada indevidamente.",
    image: "/placeholder.svg?height=200&width=300",
    author: "Dra. Luciana Santos",
    date: "9 de Fevereiro de 2024",
    readTime: "6 min de leitura",
  },
  {
    slug: "aspectos-legais-nome-empresarial",
    title: "Aspectos Legais do Nome Empresarial",
    excerpt: "Diferenças jurídicas entre marca registrada e nome empresarial: o que você precisa saber.",
    image: "/placeholder.svg?height=200&width=300",
    author: "Dr. Marcelo Costa",
    date: "7 de Fevereiro de 2024",
    readTime: "5 min de leitura",
  },
  {
    slug: "prazos-legais-registro-marca",
    title: "Prazos Legais no Registro de Marca",
    excerpt: "Entenda todos os prazos envolvidos no processo de registro e suas implicações legais.",
    image: "/placeholder.svg?height=200&width=300",
    author: "Dra. Fernanda Lima",
    date: "4 de Fevereiro de 2024",
    readTime: "6 min de leitura",
  },
  {
    slug: "recursos-administrativos-inpi",
    title: "Recursos Administrativos no INPI",
    excerpt: "Como e quando apresentar recursos administrativos durante o processo de registro.",
    image: "/placeholder.svg?height=200&width=300",
    author: "Dr. Henrique Silva",
    date: "1 de Fevereiro de 2024",
    readTime: "7 min de leitura",
  },
]

const categories = ["Todos os Artigos", "Legal", "Guia Prático", "Dicas", "Internacional", "Tecnologia", "Estratégia"]

export default function BlogPage() {
  return (
    <div className="flex flex-col min-h-screen bg-background text-white">
      <main className="flex-grow">
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold">Blog VALI</h1>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Buscar artigos..."
                  className="pl-10 pr-4 py-2 bg-gray-900 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>

            <div className="flex gap-4 mb-12 overflow-x-auto pb-4">
              {categories.map((category, index) => (
                <Button
                  key={index}
                  variant={index === 0 ? "default" : "outline"}
                  className={index === 0 ? "bg-primary" : ""}
                >
                  {category}
                </Button>
              ))}
            </div>

            <div className="mb-16">
              <Link href={`/blog/${posts[0].slug}`} className="block group">
                <div className="relative rounded-2xl overflow-hidden">
                  <Image
                    src={posts[0].image || "/placeholder.svg"}
                    width={800}
                    height={400}
                    alt={posts[0].title}
                    className="w-full h-[400px] object-cover transition-transform group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-8">
                    <span className="text-primary font-semibold mb-2">Legal</span>
                    <h2 className="text-3xl font-bold mb-4">{posts[0].title}</h2>
                    <p className="text-gray-300 mb-4">{posts[0].excerpt}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-300">
                      <div className="flex items-center gap-2">
                        <User2 size={16} />
                        {posts[0].author}
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock size={16} />
                        {posts[0].readTime}
                      </div>
                      <span>{posts[0].date}</span>
                    </div>
                  </div>
                </div>
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {posts.slice(1).map((post, index) => (
                <Link key={index} href={`/blog/${post.slug}`} className="group">
                  <div className="bg-gray-900 rounded-xl overflow-hidden">
                    <div className="relative h-48">
                      <Image
                        src={post.image || "/placeholder.svg"}
                        fill
                        alt={post.title}
                        className="object-cover transition-transform group-hover:scale-105"
                      />
                    </div>
                    <div className="p-6">
                      <span className="text-primary text-sm font-semibold">Legal</span>
                      <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">
                        {post.title}
                      </h3>
                      <p className="text-gray-400 mb-4 line-clamp-2">{post.excerpt}</p>
                      <div className="flex items-center justify-between text-sm text-gray-400">
                        <div className="flex items-center gap-2">
                          <User2 size={16} />
                          {post.author}
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock size={16} />
                          {post.readTime}
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>

            <div className="mt-12 text-center">
              <Button className="bg-gradient-to-r from-primary to-secondary">
                Carregar mais artigos
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>

        <section className="py-20 bg-gray-900">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-8">Receba Novidades em Primeira Mão</h2>
            <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
              Inscreva-se em nossa newsletter e receba as últimas atualizações sobre registro de marcas e propriedade
              intelectual
            </p>
            <div className="flex gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Seu melhor e-mail"
                className="flex-1 px-4 py-2 bg-background rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <Button className="bg-gradient-to-r from-primary to-secondary">Inscrever-se</Button>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}


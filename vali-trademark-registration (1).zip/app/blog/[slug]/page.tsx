import { Button } from "@/components/ui/button"
import {
  ArrowLeft,
  Calendar,
  Clock,
  User2,
  Share2,
  Facebook,
  Twitter,
  Linkedin,
  Copy,
  ChevronRight,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"

// Dados simulados dos artigos do blog
const blogPosts = [
  {
    slug: "entenda-nova-lei-propriedade-industrial",
    title: "Entenda a Nova Lei da Propriedade Industrial",
    excerpt:
      "Uma análise completa das mudanças recentes na legislação de propriedade industrial e como elas afetam o registro de marcas no Brasil.",
    content: `
      <p class="lead text-xl text-gray-300">
        Uma análise completa das mudanças recentes na legislação de propriedade industrial e como elas afetam o
        registro de marcas no Brasil. Entenda o que mudou e como isso impacta seu negócio.
      </p>

      <h2>Introdução às Mudanças Legislativas</h2>
      <p>
        A Lei de Propriedade Industrial (LPI) brasileira passou por significativas atualizações nos últimos
        meses, trazendo importantes modificações para o processo de registro de marcas, patentes e desenhos
        industriais. Estas alterações visam modernizar o sistema de propriedade intelectual do país, tornando-o
        mais eficiente e alinhado com as melhores práticas internacionais.
      </p>
      <p>
        As mudanças foram motivadas pela necessidade de reduzir o backlog de pedidos no INPI (Instituto Nacional
        da Propriedade Industrial) e agilizar os processos de concessão de direitos de propriedade intelectual,
        que historicamente enfrentavam longos períodos de espera.
      </p>

      <h2>Principais Alterações na Lei</h2>
      <p>
        Entre as principais mudanças introduzidas pela nova legislação, destacam-se:
      </p>

      <h3>1. Simplificação do Processo de Registro</h3>
      <p>
        O processo de registro de marcas foi significativamente simplificado, com a redução de etapas
        burocráticas e a implementação de um sistema mais intuitivo para os requerentes. A documentação exigida
        foi racionalizada, e muitos procedimentos que antes exigiam intervenção manual agora são automatizados.
      </p>

      <h3>2. Exame Prioritário</h3>
      <p>
        Foi instituído um sistema de exame prioritário para determinadas categorias de pedidos, incluindo:
      </p>
      <ul>
        <li>Micro e pequenas empresas</li>
        <li>Startups e empresas inovadoras</li>
        <li>Instituições científicas e tecnológicas</li>
        <li>Pedidos relacionados a tecnologias verdes e sustentáveis</li>
        <li>Pedidos relacionados a tratamentos de saúde</li>
      </ul>
      <p>
        Este sistema permite que pedidos nestas categorias sejam analisados com precedência, reduzindo
        significativamente o tempo de espera para a concessão do registro.
      </p>

      <h3>3. Multiclasse e Divisão de Pedidos</h3>
      <p>
        Uma das inovações mais significativas é a implementação do sistema multiclasse, que permite ao requerente
        solicitar o registro de uma marca em várias classes de produtos ou serviços em um único pedido. Além
        disso, foi introduzida a possibilidade de divisão de pedidos, permitindo que um pedido original seja
        dividido em dois ou mais pedidos, cada um contendo parte dos produtos ou serviços inicialmente
        reivindicados.
      </p>

      <h3>4. Oposição e Processo Administrativo de Nulidade</h3>
      <p>
        Os procedimentos de oposição e de processo administrativo de nulidade foram revisados, com a introdução
        de prazos mais curtos e procedimentos mais eficientes. Agora, o prazo para apresentação de oposição é de
        60 dias contados da publicação do pedido, e o requerente tem o mesmo prazo para apresentar sua
        manifestação à oposição.
      </p>

      <h2>Impactos para os Titulares de Marcas</h2>
      <p>
        As mudanças na legislação trazem diversos benefícios para os titulares de marcas, mas também exigem
        atenção a novos aspectos do processo de registro. Entre os principais impactos, destacam-se:
      </p>

      <h3>Benefícios</h3>
      <ul>
        <li>Redução no tempo de concessão do registro</li>
        <li>Simplificação do processo e redução de custos</li>
        <li>Maior segurança jurídica com procedimentos mais claros</li>
        <li>Alinhamento com padrões internacionais, facilitando registros no exterior</li>
        <li>Possibilidade de proteção em múltiplas classes com um único pedido</li>
      </ul>

      <h3>Pontos de Atenção</h3>
      <ul>
        <li>Necessidade de adaptação às novas regras e procedimentos</li>
        <li>Importância de uma estratégia mais abrangente para proteção multiclasse</li>
        <li>Maior vigilância quanto a oposições, devido aos prazos mais curtos</li>
        <li>Necessidade de monitoramento mais eficiente do mercado</li>
      </ul>

      <h2>Conclusão</h2>
      <p>
        As recentes mudanças na Lei de Propriedade Industrial representam um avanço significativo para o sistema
        brasileiro de propriedade intelectual, trazendo maior eficiência, simplicidade e alinhamento com padrões
        internacionais. Para os titulares de marcas, estas mudanças oferecem oportunidades importantes para
        fortalecer a proteção de seus ativos intangíveis, mas também exigem adaptação e atenção às novas regras e
        procedimentos.
      </p>
      <p>
        Na VALI, estamos preparados para auxiliar nossos clientes a navegar por este novo cenário, oferecendo
        consultoria especializada e serviços adaptados às novas exigências legais. Entre em contato conosco para
        saber como podemos ajudar sua empresa a proteger suas marcas de forma eficiente e estratégica.
      </p>
    `,
    image: "/placeholder.svg?height=800&width=1600",
    author: {
      name: "Dra. Patricia Mendes",
      role: "Especialista em Direito da Propriedade Intelectual",
      bio: "Advogada com mais de 15 anos de experiência em propriedade intelectual, especialista em registro de marcas e patentes. Mestre em Direito Empresarial e pós-graduada em Propriedade Intelectual pela USP. Palestrante e autora de diversos artigos sobre o tema.",
      avatar: "/placeholder.svg?height=120&width=120",
    },
    date: "14 de Fevereiro de 2024",
    readTime: "8 min de leitura",
    category: "Legal",
  },
  {
    slug: "direitos-deveres-titular-marca",
    title: "Direitos e Deveres do Titular de Marca",
    excerpt: "Conheça todos os direitos que você adquire ao registrar uma marca e suas responsabilidades legais.",
    content: `
      <p class="lead text-xl text-gray-300">
        Ao registrar uma marca, você adquire uma série de direitos exclusivos, mas também assume responsabilidades importantes. Entenda o equilíbrio entre direitos e deveres do titular de marca.
      </p>

      <h2>Direitos do Titular de Marca</h2>
      <p>
        O registro de marca confere ao seu titular um conjunto de direitos exclusivos que são essenciais para a proteção e valorização deste importante ativo intangível. Compreender estes direitos é fundamental para exercê-los plenamente e defender sua marca no mercado.
      </p>

      <h3>1. Exclusividade de Uso</h3>
      <p>
        O principal direito adquirido com o registro é a exclusividade de uso da marca em todo o território nacional, na classe para a qual foi registrada. Isso significa que apenas o titular pode utilizar a marca para identificar produtos ou serviços idênticos, semelhantes ou afins.
      </p>

      <h3>2. Direito de Impedir Uso por Terceiros</h3>
      <p>
        O titular pode impedir que terceiros utilizem, sem sua autorização, marca idêntica ou semelhante para produtos ou serviços idênticos, semelhantes ou afins, quando tal uso possa causar confusão ou associação indevida no mercado.
      </p>

      <h3>3. Possibilidade de Licenciamento</h3>
      <p>
        O titular pode licenciar o uso de sua marca para terceiros, mediante contratos de licenciamento, obtendo retorno financeiro através de royalties. Estes contratos devem ser registrados no INPI para produzirem efeitos perante terceiros.
      </p>

      <h3>4. Direito de Zelar pela Integridade</h3>
      <p>
        O titular tem o direito de zelar pela integridade material e reputação de sua marca, podendo agir contra qualquer uso que possa prejudicar sua distintividade ou reputação.
      </p>

      <h3>5. Direito de Transferência</h3>
      <p>
        A marca pode ser transferida por cessão ou em razão de sucessão legítima ou testamentária. A transferência deve ser registrada no INPI para produzir efeitos perante terceiros.
      </p>

      <h2>Deveres do Titular de Marca</h2>
      <p>
        Junto com os direitos, o titular de marca também assume importantes responsabilidades, que devem ser observadas para manter a validade e eficácia do registro.
      </p>

      <h3>1. Uso Efetivo da Marca</h3>
      <p>
        O titular deve utilizar efetivamente a marca no mercado, nos produtos ou serviços para os quais foi registrada. A falta de uso por mais de 5 anos consecutivos pode levar à caducidade do registro, mediante requerimento de terceiro interessado.
      </p>

      <h3>2. Renovação do Registro</h3>
      <p>
        O registro de marca tem validade de 10 anos, contados da data de concessão, podendo ser prorrogado por períodos iguais e sucessivos. É dever do titular solicitar a renovação no último ano de vigência do registro ou, mediante pagamento de taxa adicional, nos 6 meses subsequentes ao término da vigência.
      </p>

      <h3>3. Manutenção da Distintividade</h3>
      <p>
        O titular deve zelar pela manutenção do caráter distintivo de sua marca, evitando que ela se torne genérica ou descritiva para o segmento em que atua. Marcas que se tornam sinônimo de categoria de produtos podem perder sua proteção.
      </p>

      <h3>4. Uso Adequado da Marca</h3>
      <p>
        A marca deve ser utilizada conforme registrada, sem alterações significativas que possam comprometer sua identidade. Alterações substanciais podem exigir novo registro.
      </p>

      <h3>5. Vigilância e Defesa</h3>
      <p>
        É dever do titular monitorar o mercado e agir contra violações de sua marca. A inércia prolongada diante de infrações pode levar à perda do direito de agir contra o infrator, por meio do instituto da supressio.
      </p>

      <h2>Consequências do Descumprimento dos Deveres</h2>
      <p>
        O descumprimento dos deveres do titular pode acarretar sérias consequências, incluindo:
      </p>
      <ul>
        <li>Caducidade do registro por falta de uso</li>
        <li>Perda do registro por não renovação</li>
        <li>Degeneração da marca, tornando-a genérica</li>
        <li>Limitação do direito de agir contra infratores</li>
        <li>Redução do valor econômico da marca</li>
      </ul>

      <h2>Conclusão</h2>
      <p>
        O equilíbrio entre direitos e deveres é fundamental para a gestão eficaz de uma marca registrada. Enquanto os direitos conferem proteção e exclusividade, os deveres garantem que a marca mantenha sua função distintiva no mercado e continue a agregar valor ao negócio.
      </p>
      <p>
        Na VALI, oferecemos consultoria especializada para auxiliar os titulares de marcas a exercerem plenamente seus direitos e cumprirem adequadamente seus deveres, maximizando o valor deste importante ativo e garantindo sua proteção efetiva no mercado.
      </p>
    `,
    image: "/placeholder.svg?height=800&width=1600",
    author: {
      name: "Dr. Roberto Alves",
      role: "Advogado Especialista em Propriedade Intelectual",
      bio: "Advogado com especialização em Direito Empresarial e Propriedade Intelectual. Possui mais de 10 anos de experiência assessorando empresas nacionais e internacionais na proteção de seus ativos intangíveis.",
      avatar: "/placeholder.svg?height=120&width=120",
    },
    date: "11 de Fevereiro de 2024",
    readTime: "7 min de leitura",
    category: "Legal",
  },
  {
    slug: "como-proceder-violacao-marca",
    title: "Como Proceder em Caso de Violação de Marca",
    excerpt: "Guia legal sobre as medidas a serem tomadas quando sua marca é usada indevidamente.",
    content: `
      <p class="lead text-xl text-gray-300">
        Descobrir que sua marca está sendo utilizada indevidamente por terceiros pode ser alarmante. Este guia apresenta os passos práticos para proteger seus direitos e agir contra violações.
      </p>

      <h2>Identificando Violações de Marca</h2>
      <p>
        Antes de tomar qualquer medida, é importante identificar corretamente se está ocorrendo uma violação de marca. Nem todo uso de uma marca similar configura infração, sendo necessário avaliar diversos fatores.
      </p>

      <h3>Tipos de Violação</h3>
      <p>
        As violações de marca podem ocorrer de diversas formas:
      </p>
      <ul>
        <li><strong>Contrafação:</strong> Reprodução não autorizada de marca idêntica para produtos ou serviços idênticos</li>
        <li><strong>Imitação:</strong> Uso de marca semelhante que possa causar confusão ou associação indevida</li>
        <li><strong>Uso indevido na internet:</strong> Utilização em nomes de domínio, metatags, anúncios online</li>
        <li><strong>Diluição:</strong> Uso que diminui o caráter distintivo de marcas famosas, mesmo em segmentos diferentes</li>
        <li><strong>Trade dress:</strong> Imitação do conjunto-imagem de produtos ou estabelecimentos</li>
      </ul>

      <h2>Passos Iniciais</h2>
      <p>
        Ao identificar uma possível violação, recomendamos seguir estes passos iniciais:
      </p>

      <h3>1. Documentação</h3>
      <p>
        Reúna todas as evidências da violação: fotografias, capturas de tela, anúncios, embalagens, notas fiscais, testemunhos de consumidores confundidos, etc. Esta documentação será fundamental para qualquer medida futura.
      </p>

      <h3>2. Avaliação Técnica</h3>
      <p>
        Consulte um especialista em propriedade intelectual para avaliar se o uso realmente configura violação e quais as chances de sucesso em uma eventual ação. Nem toda semelhança constitui infração, sendo necessária uma análise técnica.
      </p>

      <h3>3. Notificação Extrajudicial</h3>
      <p>
        Na maioria dos casos, o primeiro passo é enviar uma notificação extrajudicial (cease and desist letter) ao suposto infrator, informando sobre seus direitos e solicitando a cessação imediata do uso indevido. Muitas vezes, esta medida é suficiente para resolver o problema.
      </p>

      <h2>Medidas Administrativas</h2>
      <p>
        Caso a notificação não surta efeito, existem medidas administrativas que podem ser adotadas:
      </p>

      <h3>1. Denúncia ao INPI</h3>
      <p>
        Se o infrator tiver solicitado o registro da marca violadora, é possível apresentar oposição ao pedido junto ao INPI, impedindo sua concessão.
      </p>

      <h3>2. Processo Administrativo de Nulidade</h3>
      <p>
        Se a marca violadora já estiver registrada, pode-se iniciar um Processo Administrativo de Nulidade (PAN) junto ao INPI, visando anular o registro indevido.
      </p>

      <h3>3. Denúncia a Órgãos de Defesa do Consumidor</h3>
      <p>
        Em casos que envolvam risco de confusão para o consumidor, pode-se apresentar denúncia a órgãos como Procon, Senacon ou Anvisa (no caso de produtos regulados).
      </p>

      <h2>Medidas Judiciais</h2>
      <p>
        Quando as medidas extrajudiciais e administrativas não são suficientes, é necessário recorrer ao Poder Judiciário:
      </p>

      <h3>1. Ação de Abstenção de Uso</h3>
      <p>
        Visa obter ordem judicial para que o infrator cesse imediatamente o uso da marca violadora, sob pena de multa diária.
      </p>

      <h3>2. Tutela Provisória de Urgência</h3>
      <p>
        Em casos graves, pode-se solicitar uma medida liminar para interromper imediatamente a violação, antes mesmo da decisão final do processo.
      </p>

      <h3>3. Busca e Apreensão</h3>
      <p>
        Medida que visa apreender produtos contrafeitos ou que utilizem indevidamente a marca, impedindo sua comercialização.
      </p>

      <h3>4. Indenização por Perdas e Danos</h3>
      <p>
        Ação que busca reparação financeira pelos prejuízos causados pela violação, incluindo danos materiais e morais.
      </p>

      <h2>Medidas Específicas para Violações Online</h2>
      <p>
        Para violações que ocorrem no ambiente digital, existem medidas específicas:
      </p>

      <h3>1. Notificação a Plataformas</h3>
      <p>
        Marketplaces, redes sociais e plataformas de e-commerce geralmente possuem canais específicos para denúncia de violações de propriedade intelectual.
      </p>

      <h3>2. Procedimento SACI-Adm</h3>
      <p>
        Para disputas envolvendo nomes de domínio .br, pode-se utilizar o Sistema Administrativo de Conflitos de Internet (SACI-Adm).
      </p>

      <h3>3. Notificação a Provedores de Hospedagem</h3>
      <p>
        Conforme o Marco Civil da Internet, provedores de hospedagem podem ser notificados para remover conteúdo infrator.
      </p>

      <h2>Prevenção de Violações</h2>
      <p>
        Além das medidas reativas, é fundamental adotar estratégias preventivas:
      </p>
      <ul>
        <li>Monitoramento constante do mercado e da internet</li>
        <li>Registro da marca em todas as classes relevantes</li>
        <li>Uso de símbolos de marca registrada (® ou ™)</li>
        <li>Educação do mercado sobre sua marca</li>
        <li>Contratação de serviços especializados de monitoramento</li>
      </ul>

      <h2>Conclusão</h2>
      <p>
        Agir rapidamente e de forma estratégica é essencial para proteger sua marca contra violações. Cada caso exige uma abordagem personalizada, considerando fatores como gravidade da violação, potencial de dano à reputação, custos envolvidos e objetivos comerciais.
      </p>
      <p>
        Na VALI, oferecemos serviços completos de proteção de marcas, desde o monitoramento preventivo até a representação em ações judiciais. Entre em contato para uma avaliação personalizada do seu caso.
      </p>
    `,
    image: "/placeholder.svg?height=800&width=1600",
    author: {
      name: "Dra. Luciana Santos",
      role: "Advogada Especialista em Contencioso Marcário",
      bio: "Advogada com especialização em Contencioso de Propriedade Intelectual. Possui vasta experiência em litígios envolvendo marcas e atua na defesa de empresas nacionais e multinacionais contra violações de propriedade intelectual.",
      avatar: "/placeholder.svg?height=120&width=120",
    },
    date: "9 de Fevereiro de 2024",
    readTime: "6 min de leitura",
    category: "Legal",
  },
]

// Função para encontrar artigos relacionados (excluindo o artigo atual)
const getRelatedPosts = (currentSlug: string) => {
  return blogPosts.filter((post) => post.slug !== currentSlug).slice(0, 3)
}

export default function BlogPostPage({ params }: { params: { slug: string } }) {
  // Encontrar o artigo pelo slug
  const post = blogPosts.find((post) => post.slug === params.slug) || blogPosts[0]
  const relatedPosts = getRelatedPosts(post.slug)

  return (
    <div className="flex flex-col min-h-screen bg-background text-white">
      <main className="flex-grow">
        {/* Breadcrumb */}
        <div className="bg-gray-900 py-4">
          <div className="container mx-auto px-4">
            <div className="flex items-center text-sm text-gray-400">
              <Link href="/blog" className="flex items-center hover:text-primary">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Voltar para o Blog
              </Link>
            </div>
          </div>
        </div>

        {/* Article Header */}
        <div className="relative">
          <div className="w-full h-[400px] relative">
            <Image
              src={post.image || "/placeholder.svg"}
              fill
              alt={post.title}
              className="object-cover brightness-50"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
          </div>

          <div className="container mx-auto px-4 relative -mt-40">
            <div className="bg-gray-900 rounded-xl p-8 shadow-xl max-w-4xl mx-auto">
              <div className="mb-6">
                <span className="text-primary text-sm font-semibold">{post.category}</span>
                <h1 className="text-3xl md:text-4xl font-bold mt-2 mb-4">{post.title}</h1>
                <div className="flex flex-wrap items-center gap-4 text-sm text-gray-400">
                  <div className="flex items-center gap-2">
                    <User2 size={16} />
                    <span>{post.author.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar size={16} />
                    <span>{post.date}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock size={16} />
                    <span>{post.readTime}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Article Content */}
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-3xl mx-auto">
            <div
              className="prose prose-invert prose-lg max-w-none"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />

            {/* Share Section */}
            <div className="border-t border-gray-800 mt-12 pt-8">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <Share2 className="text-primary" />
                  <span className="font-semibold">Compartilhe este artigo:</span>
                </div>
                <div className="flex items-center gap-3">
                  <Button variant="outline" size="icon" className="rounded-full">
                    <Facebook size={18} />
                  </Button>
                  <Button variant="outline" size="icon" className="rounded-full">
                    <Twitter size={18} />
                  </Button>
                  <Button variant="outline" size="icon" className="rounded-full">
                    <Linkedin size={18} />
                  </Button>
                  <Button variant="outline" size="icon" className="rounded-full">
                    <Copy size={18} />
                  </Button>
                </div>
              </div>
            </div>

            {/* Author Section */}
            <div className="bg-gray-900 rounded-xl p-6 mt-12">
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
                <Image
                  src={post.author.avatar || "/placeholder.svg"}
                  width={120}
                  height={120}
                  alt={post.author.name}
                  className="rounded-full"
                />
                <div>
                  <h3 className="text-xl font-bold mb-2">{post.author.name}</h3>
                  <p className="text-primary mb-4">{post.author.role}</p>
                  <p className="text-gray-400">{post.author.bio}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Related Articles */}
        <div className="bg-gray-900 py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-bold mb-8">Artigos Relacionados</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {relatedPosts.map((relatedPost) => (
                <Link key={relatedPost.slug} href={`/blog/${relatedPost.slug}`} className="group">
                  <div className="bg-background rounded-xl overflow-hidden">
                    <div className="relative h-48">
                      <Image
                        src={relatedPost.image || "/placeholder.svg"}
                        fill
                        alt={relatedPost.title}
                        className="object-cover transition-transform group-hover:scale-105"
                      />
                    </div>
                    <div className="p-6">
                      <span className="text-primary text-sm font-semibold">{relatedPost.category}</span>
                      <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">
                        {relatedPost.title}
                      </h3>
                      <p className="text-gray-400 mb-4 line-clamp-2">{relatedPost.excerpt}</p>
                      <div className="flex items-center justify-between text-sm text-gray-400">
                        <div className="flex items-center gap-2">
                          <User2 size={16} />
                          {relatedPost.author.name}
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock size={16} />
                          {relatedPost.readTime}
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="py-16">
          <div className="container mx-auto px-4">
            <div className="bg-gray-900 rounded-xl p-8 md:p-12 text-center max-w-4xl mx-auto">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">Precisa de ajuda com o registro da sua marca?</h2>
              <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
                Nossa equipe de especialistas está pronta para auxiliar você em todo o processo de registro, garantindo
                a proteção adequada para sua marca.
              </p>
              <Button className="bg-gradient-to-r from-primary to-secondary text-white hover:opacity-90 text-lg px-8 py-6">
                Fale com um Especialista
                <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}


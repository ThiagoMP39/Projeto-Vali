import { Button } from "@/components/ui/button"
import {
  ArrowLeft,
  Calendar,
  Clock,
  User2,
  Share2,
  Facebook,
  Twitter,
  Linkedin,
  Copy,
  ChevronRight,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function BlogPostPage() {
  return (
    <div className="flex flex-col min-h-screen bg-background text-white">
      <main className="flex-grow">
        {/* Breadcrumb */}
        <div className="bg-gray-900 py-4">
          <div className="container mx-auto px-4">
            <div className="flex items-center text-sm text-gray-400">
              <Link href="/blog" className="flex items-center hover:text-primary">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Voltar para o Blog
              </Link>
            </div>
          </div>
        </div>

        {/* Article Header */}
        <div className="relative">
          <div className="w-full h-[400px] relative">
            <Image
              src="/placeholder.svg?height=800&width=1600"
              fill
              alt="Entenda a Nova Lei da Propriedade Industrial"
              className="object-cover brightness-50"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
          </div>

          <div className="container mx-auto px-4 relative -mt-40">
            <div className="bg-gray-900 rounded-xl p-8 shadow-xl max-w-4xl mx-auto">
              <div className="mb-6">
                <span className="text-primary text-sm font-semibold">Legal</span>
                <h1 className="text-3xl md:text-4xl font-bold mt-2 mb-4">
                  Entenda a Nova Lei da Propriedade Industrial
                </h1>
                <div className="flex flex-wrap items-center gap-4 text-sm text-gray-400">
                  <div className="flex items-center gap-2">
                    <User2 size={16} />
                    <span>Dra. Patricia Mendes</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar size={16} />
                    <span>14 de Fevereiro de 2024</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock size={16} />
                    <span>8 min de leitura</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Article Content */}
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-3xl mx-auto">
            <div className="prose prose-invert prose-lg max-w-none">
              <p className="lead text-xl text-gray-300">
                Uma análise completa das mudanças recentes na legislação de propriedade industrial e como elas afetam o
                registro de marcas no Brasil. Entenda o que mudou e como isso impacta seu negócio.
              </p>

              <h2>Introdução às Mudanças Legislativas</h2>
              <p>
                A Lei de Propriedade Industrial (LPI) brasileira passou por significativas atualizações nos últimos
                meses, trazendo importantes modificações para o processo de registro de marcas, patentes e desenhos
                industriais. Estas alterações visam modernizar o sistema de propriedade intelectual do país, tornando-o
                mais eficiente e alinhado com as melhores práticas internacionais.
              </p>
              <p>
                As mudanças foram motivadas pela necessidade de reduzir o backlog de pedidos no INPI (Instituto Nacional
                da Propriedade Industrial) e agilizar os processos de concessão de direitos de propriedade intelectual,
                que historicamente enfrentavam longos períodos de espera.
              </p>

              <h2>Principais Alterações na Lei</h2>
              <p>Entre as principais mudanças introduzidas pela nova legislação, destacam-se:</p>

              <h3>1. Simplificação do Processo de Registro</h3>
              <p>
                O processo de registro de marcas foi significativamente simplificado, com a redução de etapas
                burocráticas e a implementação de um sistema mais intuitivo para os requerentes. A documentação exigida
                foi racionalizada, e muitos procedimentos que antes exigiam intervenção manual agora são automatizados.
              </p>

              <div className="bg-gray-800 p-6 rounded-xl my-8">
                <h4 className="text-primary font-semibold mb-2">Importante</h4>
                <p className="text-gray-300 mb-0">
                  Com as novas regras, o prazo médio para concessão de registros de marca deve cair de 24 meses para
                  aproximadamente 12 meses, representando uma redução de 50% no tempo de espera.
                </p>
              </div>

              <h3>2. Exame Prioritário</h3>
              <p>Foi instituído um sistema de exame prioritário para determinadas categorias de pedidos, incluindo:</p>
              <ul>
                <li>Micro e pequenas empresas</li>
                <li>Startups e empresas inovadoras</li>
                <li>Instituições científicas e tecnológicas</li>
                <li>Pedidos relacionados a tecnologias verdes e sustentáveis</li>
                <li>Pedidos relacionados a tratamentos de saúde</li>
              </ul>
              <p>
                Este sistema permite que pedidos nestas categorias sejam analisados com precedência, reduzindo
                significativamente o tempo de espera para a concessão do registro.
              </p>

              <h3>3. Multiclasse e Divisão de Pedidos</h3>
              <p>
                Uma das inovações mais significativas é a implementação do sistema multiclasse, que permite ao
                requerente solicitar o registro de uma marca em várias classes de produtos ou serviços em um único
                pedido. Além disso, foi introduzida a possibilidade de divisão de pedidos, permitindo que um pedido
                original seja dividido em dois ou mais pedidos, cada um contendo parte dos produtos ou serviços
                inicialmente reivindicados.
              </p>

              <Image
                src="/placeholder.svg?height=400&width=800"
                width={800}
                height={400}
                alt="Sistema multiclasse de registro de marcas"
                className="my-8 rounded-xl"
              />

              <h3>4. Oposição e Processo Administrativo de Nulidade</h3>
              <p>
                Os procedimentos de oposição e de processo administrativo de nulidade foram revisados, com a introdução
                de prazos mais curtos e procedimentos mais eficientes. Agora, o prazo para apresentação de oposição é de
                60 dias contados da publicação do pedido, e o requerente tem o mesmo prazo para apresentar sua
                manifestação à oposição.
              </p>

              <h2>Impactos para os Titulares de Marcas</h2>
              <p>
                As mudanças na legislação trazem diversos benefícios para os titulares de marcas, mas também exigem
                atenção a novos aspectos do processo de registro. Entre os principais impactos, destacam-se:
              </p>

              <h3>Benefícios</h3>
              <ul>
                <li>Redução no tempo de concessão do registro</li>
                <li>Simplificação do processo e redução de custos</li>
                <li>Maior segurança jurídica com procedimentos mais claros</li>
                <li>Alinhamento com padrões internacionais, facilitando registros no exterior</li>
                <li>Possibilidade de proteção em múltiplas classes com um único pedido</li>
              </ul>

              <h3>Pontos de Atenção</h3>
              <ul>
                <li>Necessidade de adaptação às novas regras e procedimentos</li>
                <li>Importância de uma estratégia mais abrangente para proteção multiclasse</li>
                <li>Maior vigilância quanto a oposições, devido aos prazos mais curtos</li>
                <li>Necessidade de monitoramento mais eficiente do mercado</li>
              </ul>

              <h2>Recomendações Práticas</h2>
              <p>
                Diante das mudanças na legislação, recomendamos as seguintes ações para empresas e empreendedores que
                desejam proteger suas marcas:
              </p>

              <ol>
                <li>
                  <strong>Revisão da estratégia de proteção:</strong> Avalie se sua estratégia atual de proteção de
                  marcas está adequada às novas possibilidades oferecidas pela legislação, especialmente quanto à
                  proteção multiclasse.
                </li>
                <li>
                  <strong>Monitoramento de marcas:</strong> Implemente ou aprimore sistemas de monitoramento de marcas
                  para identificar rapidamente possíveis violações ou pedidos conflitantes.
                </li>
                <li>
                  <strong>Consultoria especializada:</strong> Conte com o apoio de especialistas em propriedade
                  intelectual para navegar pelas novas regras e maximizar os benefícios das mudanças legislativas.
                </li>
                <li>
                  <strong>Treinamento e atualização:</strong> Mantenha-se atualizado sobre as interpretações e
                  aplicações práticas da nova legislação, participando de treinamentos e acompanhando publicações
                  especializadas.
                </li>
                <li>
                  <strong>Revisão de portfólio:</strong> Aproveite as novas regras para revisar seu portfólio de marcas,
                  identificando oportunidades de consolidação ou expansão da proteção.
                </li>
              </ol>

              <h2>Conclusão</h2>
              <p>
                As recentes mudanças na Lei de Propriedade Industrial representam um avanço significativo para o sistema
                brasileiro de propriedade intelectual, trazendo maior eficiência, simplicidade e alinhamento com padrões
                internacionais. Para os titulares de marcas, estas mudanças oferecem oportunidades importantes para
                fortalecer a proteção de seus ativos intangíveis, mas também exigem adaptação e atenção às novas regras
                e procedimentos.
              </p>
              <p>
                Na VALI, estamos preparados para auxiliar nossos clientes a navegar por este novo cenário, oferecendo
                consultoria especializada e serviços adaptados às novas exigências legais. Entre em contato conosco para
                saber como podemos ajudar sua empresa a proteger suas marcas de forma eficiente e estratégica.
              </p>
            </div>

            {/* Share Section */}
            <div className="border-t border-gray-800 mt-12 pt-8">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <Share2 className="text-primary" />
                  <span className="font-semibold">Compartilhe este artigo:</span>
                </div>
                <div className="flex items-center gap-3">
                  <Button variant="outline" size="icon" className="rounded-full">
                    <Facebook size={18} />
                  </Button>
                  <Button variant="outline" size="icon" className="rounded-full">
                    <Twitter size={18} />
                  </Button>
                  <Button variant="outline" size="icon" className="rounded-full">
                    <Linkedin size={18} />
                  </Button>
                  <Button variant="outline" size="icon" className="rounded-full">
                    <Copy size={18} />
                  </Button>
                </div>
              </div>
            </div>

            {/* Author Section */}
            <div className="bg-gray-900 rounded-xl p-6 mt-12">
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
                <Image
                  src="/placeholder.svg?height=120&width=120"
                  width={120}
                  height={120}
                  alt="Dra. Patricia Mendes"
                  className="rounded-full"
                />
                <div>
                  <h3 className="text-xl font-bold mb-2">Dra. Patricia Mendes</h3>
                  <p className="text-primary mb-4">Especialista em Direito da Propriedade Intelectual</p>
                  <p className="text-gray-400">
                    Advogada com mais de 15 anos de experiência em propriedade intelectual, especialista em registro de
                    marcas e patentes. Mestre em Direito Empresarial e pós-graduada em Propriedade Intelectual pela USP.
                    Palestrante e autora de diversos artigos sobre o tema.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Related Articles */}
        <div className="bg-gray-900 py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-bold mb-8">Artigos Relacionados</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Link href="/blog/post" className="group">
                <div className="bg-background rounded-xl overflow-hidden">
                  <div className="relative h-48">
                    <Image
                      src="/placeholder.svg?height=200&width=300"
                      fill
                      alt="Direitos e Deveres do Titular de Marca"
                      className="object-cover transition-transform group-hover:scale-105"
                    />
                  </div>
                  <div className="p-6">
                    <span className="text-primary text-sm font-semibold">Legal</span>
                    <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">
                      Direitos e Deveres do Titular de Marca
                    </h3>
                    <p className="text-gray-400 mb-4 line-clamp-2">
                      Conheça todos os direitos que você adquire ao registrar uma marca e suas responsabilidades legais.
                    </p>
                    <div className="flex items-center justify-between text-sm text-gray-400">
                      <div className="flex items-center gap-2">
                        <User2 size={16} />
                        Dr. Roberto Alves
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock size={16} />7 min de leitura
                      </div>
                    </div>
                  </div>
                </div>
              </Link>

              <Link href="/blog/post" className="group">
                <div className="bg-background rounded-xl overflow-hidden">
                  <div className="relative h-48">
                    <Image
                      src="/placeholder.svg?height=200&width=300"
                      fill
                      alt="Como Proceder em Caso de Violação de Marca"
                      className="object-cover transition-transform group-hover:scale-105"
                    />
                  </div>
                  <div className="p-6">
                    <span className="text-primary text-sm font-semibold">Legal</span>
                    <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">
                      Como Proceder em Caso de Violação de Marca
                    </h3>
                    <p className="text-gray-400 mb-4 line-clamp-2">
                      Guia legal sobre as medidas a serem tomadas quando sua marca é usada indevidamente.
                    </p>
                    <div className="flex items-center justify-between text-sm text-gray-400">
                      <div className="flex items-center gap-2">
                        <User2 size={16} />
                        Dra. Luciana Santos
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock size={16} />6 min de leitura
                      </div>
                    </div>
                  </div>
                </div>
              </Link>

              <Link href="/blog/post" className="group">
                <div className="bg-background rounded-xl overflow-hidden">
                  <div className="relative h-48">
                    <Image
                      src="/placeholder.svg?height=200&width=300"
                      fill
                      alt="Aspectos Legais do Nome Empresarial"
                      className="object-cover transition-transform group-hover:scale-105"
                    />
                  </div>
                  <div className="p-6">
                    <span className="text-primary text-sm font-semibold">Legal</span>
                    <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">
                      Aspectos Legais do Nome Empresarial
                    </h3>
                    <p className="text-gray-400 mb-4 line-clamp-2">
                      Diferenças jurídicas entre marca registrada e nome empresarial: o que você precisa saber.
                    </p>
                    <div className="flex items-center justify-between text-sm text-gray-400">
                      <div className="flex items-center gap-2">
                        <User2 size={16} />
                        Dr. Marcelo Costa
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock size={16} />5 min de leitura
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="py-16">
          <div className="container mx-auto px-4">
            <div className="bg-gray-900 rounded-xl p-8 md:p-12 text-center max-w-4xl mx-auto">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">Precisa de ajuda com o registro da sua marca?</h2>
              <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
                Nossa equipe de especialistas está pronta para auxiliar você em todo o processo de registro, garantindo
                a proteção adequada para sua marca.
              </p>
              <Button className="bg-gradient-to-r from-primary to-secondary text-white hover:opacity-90 text-lg px-8 py-6">
                Fale com um Especialista
                <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}


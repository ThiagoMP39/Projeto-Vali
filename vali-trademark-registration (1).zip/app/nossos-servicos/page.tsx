import { Button } from "@/components/ui/button"
import { CheckCircle2 } from "lucide-react"
import { AnimatedSection } from "@/components/animated-section"
import { AnimatedList } from "@/components/animated-list"

export default function ServicesPage() {
  return (
    <div className="flex flex-col min-h-screen bg-background text-white">
      <main className="flex-grow">
        <section className="py-20">
          <div className="container mx-auto px-4">
            <AnimatedSection variant="fadeIn" className="max-w-3xl mx-auto text-center mb-16">
              <h1 className="text-4xl font-bold mb-6">Nossos Serviços de Registro de Marca</h1>
              <p className="text-xl text-gray-400">
                Oferecemos soluções completas para proteger sua marca e garantir seus direitos de propriedade
                intelectual
              </p>
            </AnimatedSection>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
              <AnimatedSection variant="fadeInLeft" delay={0.1}>
                <div className="bg-gray-900 rounded-xl p-8">
                  <h3 className="text-2xl font-bold mb-4">Registro de Marca Nacional</h3>
                  <p className="text-gray-400 mb-6">
                    Proteja sua marca em todo o território brasileiro com nosso serviço completo de registro junto ao
                    INPI. Nossa equipe oferece assistência personalizada em cada etapa do processo.
                  </p>
                  <AnimatedList variant="fadeInUp" staggerDelay={0.1}>
                    <li className="flex items-center gap-3">
                      <CheckCircle2 className="text-green-500" />
                      <span>Pesquisa prévia de anterioridade</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle2 className="text-green-500" />
                      <span>Análise de viabilidade</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle2 className="text-green-500" />
                      <span>Preparação e depósito do pedido</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle2 className="text-green-500" />
                      <span>Assistência no acompanhamento do processo</span>
                    </li>
                  </AnimatedList>
                  <AnimatedSection variant="fadeIn" delay={0.5} className="mt-8">
                    <Button className="w-full bg-gradient-to-r from-primary to-secondary">Solicitar Registro</Button>
                  </AnimatedSection>
                </div>
              </AnimatedSection>

              <AnimatedSection variant="fadeInRight" delay={0.1}>
                <div className="bg-gray-900 rounded-xl p-8">
                  <h3 className="text-2xl font-bold mb-4">Registro Internacional</h3>
                  <p className="text-gray-400 mb-6">
                    Expanda a proteção da sua marca para outros países através do Protocolo de Madri.
                  </p>
                  <AnimatedList variant="fadeInUp" staggerDelay={0.1}>
                    <li className="flex items-center gap-3">
                      <CheckCircle2 className="text-green-500" />
                      <span>Análise estratégica de mercados</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle2 className="text-green-500" />
                      <span>Registro em múltiplos países</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle2 className="text-green-500" />
                      <span>Gestão internacional da marca</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <CheckCircle2 className="text-green-500" />
                      <span>Suporte multilíngue</span>
                    </li>
                  </AnimatedList>
                  <AnimatedSection variant="fadeIn" delay={0.5} className="mt-8">
                    <Button className="w-full bg-gradient-to-r from-primary to-secondary">Consultar Viabilidade</Button>
                  </AnimatedSection>
                </div>
              </AnimatedSection>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-gray-900 rounded-xl p-6 h-full flex flex-col">
                <h3 className="text-xl font-bold mb-4">Monitoramento de Marca</h3>
                <p className="text-gray-400 mb-6 flex-grow">
                  Acompanhamento constante para identificar possíveis violações e usos indevidos da sua marca.
                </p>
                <Button variant="outline" className="w-full mt-auto">
                  Saiba Mais
                </Button>
              </div>

              <div className="bg-gray-900 rounded-xl p-6 h-full flex flex-col">
                <h3 className="text-xl font-bold mb-4">Oposição e Defesa</h3>
                <p className="text-gray-400 mb-6 flex-grow">
                  Suporte jurídico especializado para defender seus direitos de propriedade intelectual.
                </p>
                <Button variant="outline" className="w-full mt-auto">
                  Saiba Mais
                </Button>
              </div>

              <div className="bg-gray-900 rounded-xl p-6 h-full flex flex-col">
                <h3 className="text-xl font-bold mb-4">Transferência de Titularidade</h3>
                <p className="text-gray-400 mb-6 flex-grow">
                  Assessoria completa em processos de compra, venda ou transferência de marcas.
                </p>
                <Button variant="outline" className="w-full mt-auto">
                  Saiba Mais
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-gray-900">
          <div className="container mx-auto px-4">
            <AnimatedSection variant="fadeInUp" className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl font-bold mb-6">Precisa de um Serviço Personalizado?</h2>
              <p className="text-gray-400 mb-8">
                Entre em contato conosco para uma consultoria gratuita e descubra a melhor solução para sua marca
              </p>
              <Button className="bg-gradient-to-r from-primary to-secondary text-white hover:opacity-90 text-lg px-8 py-6">
                Agendar Consultoria
              </Button>
            </AnimatedSection>
          </div>
        </section>
      </main>
    </div>
  )
}


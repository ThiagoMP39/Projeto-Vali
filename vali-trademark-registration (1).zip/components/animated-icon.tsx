"use client"

import { type ReactNode, useRef } from "react"
import { motion, useInView } from "framer-motion"

type IconAnimationVariant = "bounce" | "pulse" | "rotate" | "scale" | "shake"

interface AnimatedIconProps {
  children: ReactNode
  className?: string
  variant?: IconAnimationVariant
  delay?: number
  duration?: number
  hover?: boolean
}

export function AnimatedIcon({
  children,
  className = "",
  variant = "pulse",
  delay = 0,
  duration = 0.5,
  hover = true,
}: AnimatedIconProps) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: false, margin: "-50px" })

  const getInitialAnimation = () => {
    switch (variant) {
      case "bounce":
        return { y: [0, -10, 0] }
      case "pulse":
        return { scale: [1, 1.1, 1] }
      case "rotate":
        return { rotate: [0, 10, -10, 0] }
      case "scale":
        return { scale: [0, 1.2, 1] }
      case "shake":
        return { x: [0, -5, 5, -5, 0] }
      default:
        return { scale: [1, 1.1, 1] }
    }
  }

  const getHoverAnimation = () => {
    switch (variant) {
      case "bounce":
        return { y: -7 }
      case "pulse":
        return { scale: 1.1 }
      case "rotate":
        return { rotate: 10 }
      case "scale":
        return { scale: 1.2 }
      case "shake":
        return { x: [0, -3, 3, -3, 0] }
      default:
        return { scale: 1.1 }
    }
  }

  return (
    <div ref={ref} className={className}>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{
          opacity: 1,
          ...(isInView ? getInitialAnimation() : {}),
        }}
        transition={{
          duration: variant === "shake" ? 0.5 : 1,
          delay,
          repeat: 0,
          ease: "easeOut",
          times: variant === "shake" ? [0, 0.25, 0.5, 0.75, 1] : [0, 0.5, 1],
        }}
        whileHover={hover ? getHoverAnimation() : undefined}
      >
        {children}
      </motion.div>
    </div>
  )
}


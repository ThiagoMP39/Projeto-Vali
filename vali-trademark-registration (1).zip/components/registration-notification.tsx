"use client"

import { X } from "lucide-react"
import { useEffect, useState } from "react"
import { AnimatePresence, motion } from "framer-motion"

// Lista de nomes brasileiros aleatórios
const randomNames = [
  "Ana Silva",
  "João Oliveira",
  "Maria Santos",
  "Pedro Costa",
  "Juliana Almeida",
  "Carlos Rodrigues",
  "Fernanda Lima",
  "Roberto Souza",
  "Mariana Pereira",
  "Lucas Ferreira",
  "Camila Ribeiro",
  "Bruno Carvalho",
  "Patrícia Gomes",
  "Gustavo Martins",
  "Aline Barbosa",
  "Rafael Mendes",
  "Daniela Cardoso",
  "Marcelo Vieira",
  "Luciana Nunes",
  "Felipe Moreira",
  "Tatiana Rocha",
  "Eduardo Teixeira",
  "Cristina Duarte",
  "Rodrigo Campos",
  "Beatriz Freitas",
  "Alexandre Dias",
  "Natália Ramos",
  "Thiago Lopes",
  "Vanessa Gonçalves",
  "Leonardo Alves",
  "Renata Castro",
  "Fábio Nascimento",
  "Larissa Pinto",
  "Diego Andrade",
  "Carla Monteiro",
  "Vinícius Araújo",
  "Amanda Correia",
  "Márcio Fernandes",
  "Jéssica Barros",
  "Henrique Cavalcanti",
  "Priscila Melo",
  "Leandro Azevedo",
  "Bianca Cunha",
  "Ricardo Borges",
  "Eliane Fonseca",
]

// Lista de cidades brasileiras
const randomCities = [
  "São Paulo",
  "Rio de Janeiro",
  "Belo Horizonte",
  "Salvador",
  "Brasília",
  "Fortaleza",
  "Recife",
  "Curitiba",
  "Porto Alegre",
  "Manaus",
  "Florianópolis",
  "Goiânia",
  "Belém",
  "Campinas",
  "Vitória",
  "Natal",
  "João Pessoa",
  "Ribeirão Preto",
  "Uberlândia",
  "Sorocaba",
  "Londrina",
  "Joinville",
  "Niterói",
  "Santos",
  "Aracaju",
  "São Luís",
  "Maceió",
  "Campo Grande",
  "Teresina",
  "Maringá",
]

// Tipos de negócios com gênero (masculino ou feminino)
const businessTypes = [
  { name: "Restaurante", gender: "masculine" },
  { name: "Loja de Roupas", gender: "feminine" },
  { name: "Consultoria", gender: "feminine" },
  { name: "Aplicativo", gender: "masculine" },
  { name: "Salão de Beleza", gender: "masculine" },
  { name: "Academia", gender: "feminine" },
  { name: "Escola de Idiomas", gender: "feminine" },
  { name: "Clínica Estética", gender: "feminine" },
  { name: "Agência de Marketing", gender: "feminine" },
  { name: "Café", gender: "masculine" },
  { name: "Padaria", gender: "feminine" },
  { name: "Estúdio de Yoga", gender: "masculine" },
  { name: "Loja Virtual", gender: "feminine" },
  { name: "Escritório de Advocacia", gender: "masculine" },
  { name: "Clínica Odontológica", gender: "feminine" },
  { name: "Cervejaria Artesanal", gender: "feminine" },
  { name: "Estúdio de Tatuagem", gender: "masculine" },
  { name: "Coworking", gender: "masculine" },
  { name: "Pet Shop", gender: "masculine" },
  { name: "Loja de Suplementos", gender: "feminine" },
  { name: "Hamburgueria", gender: "feminine" },
  { name: "Imobiliária", gender: "feminine" },
  { name: "Escola Infantil", gender: "feminine" },
  { name: "Farmácia", gender: "feminine" },
  { name: "Loja de Decoração", gender: "feminine" },
  { name: "Estúdio de Fotografia", gender: "masculine" },
  { name: "Barbearia", gender: "feminine" },
  { name: "Confeitaria", gender: "feminine" },
  { name: "Loja de Cosméticos Naturais", gender: "feminine" },
  { name: "Clínica Veterinária", gender: "feminine" },
  { name: "Agência de Viagens", gender: "feminine" },
  { name: "Loja de Produtos Orgânicos", gender: "feminine" },
  { name: "Consultório de Nutrição", gender: "masculine" },
  { name: "Estúdio de Pilates", gender: "masculine" },
  { name: "Loja de Artesanato", gender: "feminine" },
  { name: "Buffet Infantil", gender: "masculine" },
  { name: "Loja de Calçados", gender: "feminine" },
  { name: "Clínica de Fisioterapia", gender: "feminine" },
  { name: "Joalheria", gender: "feminine" },
  { name: "Loja de Informática", gender: "feminine" },
  { name: "Curso Online", gender: "masculine" },
  { name: "Delivery de Comida Saudável", gender: "masculine" },
  { name: "Loja de Produtos Sustentáveis", gender: "feminine" },
  { name: "Estúdio de Dança", gender: "masculine" },
  { name: "Consultoria Financeira", gender: "feminine" },
]

// Tempos aleatórios
const randomTimes = [
  { text: "há poucos segundos", recency: 1 },
  { text: "há 1 minuto", recency: 2 },
  { text: "há 2 minutos", recency: 3 },
  { text: "há 5 minutos", recency: 4 },
  { text: "há 10 minutos", recency: 5 },
  { text: "há 15 minutos", recency: 6 },
  { text: "há 20 minutos", recency: 7 },
  { text: "há 30 minutos", recency: 8 },
  { text: "há 45 minutos", recency: 9 },
  { text: "há 1 hora", recency: 10 },
]

export function RegistrationNotification() {
  const [isVisible, setIsVisible] = useState(false)
  const [notification, setNotification] = useState({
    name: "",
    city: "",
    business: { name: "", gender: "masculine" },
    time: { text: "há poucos segundos", recency: 1 },
  })

  // Gerar uma notificação aleatória
  const generateRandomNotification = () => {
    const randomName = randomNames[Math.floor(Math.random() * randomNames.length)]
    const randomCity = randomCities[Math.floor(Math.random() * randomCities.length)]
    const randomBusiness = businessTypes[Math.floor(Math.random() * businessTypes.length)]
    const randomTime = randomTimes[Math.floor(Math.random() * randomTimes.length)]

    setNotification({
      name: randomName,
      city: randomCity,
      business: randomBusiness,
      time: randomTime,
    })
  }

  useEffect(() => {
    // Gerar a primeira notificação após 3 segundos
    const initialTimeout = setTimeout(() => {
      generateRandomNotification()
      setIsVisible(true)
    }, 3000)

    // Configurar um intervalo para mostrar novas notificações
    const interval = setInterval(() => {
      if (Math.random() > 0.5) {
        // 50% de chance de mostrar uma nova notificação
        generateRandomNotification()
        setIsVisible(true)
      }
    }, 15000) // A cada 15 segundos

    // Limpar timeouts e intervalos
    return () => {
      clearTimeout(initialTimeout)
      clearInterval(interval)
    }
  }, []) // Removed generateRandomNotification from dependencies

  // Auto-esconder a notificação após 5 segundos
  useEffect(() => {
    if (isVisible) {
      const timeout = setTimeout(() => {
        setIsVisible(false)
      }, 5000)

      return () => clearTimeout(timeout)
    }
  }, [isVisible]) // Removed notification from dependencies

  // Determinar o artigo correto com base no gênero do negócio
  const getArticle = () => {
    return notification.business.gender === "masculine" ? "seu" : "sua"
  }

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed bottom-4 left-4 z-50 max-w-sm bg-gray-900 rounded-lg shadow-lg border border-blue-500/30"
        >
          <div className="p-4 pr-10 relative">
            <button
              onClick={() => setIsVisible(false)}
              className="absolute top-2 right-2 text-gray-400 hover:text-white"
              aria-label="Fechar notificação"
            >
              <X size={16} />
            </button>
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
              <div>
                <p className="text-sm text-gray-300">
                  <span className="font-semibold text-blue-400">{notification.name}</span> de{" "}
                  <span className="text-white">{notification.city}</span> acabou de solicitar o registro da marca para{" "}
                  {getArticle()} <span className="text-white">{notification.business.name}</span>
                </p>
                <p className="text-xs text-gray-500 mt-1">{notification.time.text}</p>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}


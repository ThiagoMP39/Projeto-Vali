"use client"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import type { ReactNode } from "react"

interface AnimatedListProps {
  children: ReactNode[]
  staggerDelay?: number
  className?: string
  animationDuration?: number
  startDelay?: number
  variant?: "fadeInUp" | "fadeInLeft" | "fadeInRight" | "fadeIn" | "zoom" | "scale"
}

export function AnimatedList({
  children,
  staggerDelay = 0.1,
  className = "",
  animationDuration = 0.5,
  startDelay = 0,
  variant = "fadeInUp",
}: AnimatedListProps) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  const getVariants = () => {
    switch (variant) {
      case "fadeInUp":
        return {
          hidden: { opacity: 0, y: 20 },
          visible: { opacity: 1, y: 0 },
        }
      case "fadeInLeft":
        return {
          hidden: { opacity: 0, x: 20 },
          visible: { opacity: 1, x: 0 },
        }
      case "fadeInRight":
        return {
          hidden: { opacity: 0, x: -20 },
          visible: { opacity: 1, x: 0 },
        }
      case "fadeIn":
        return {
          hidden: { opacity: 0 },
          visible: { opacity: 1 },
        }
      case "zoom":
        return {
          hidden: { opacity: 0, scale: 0.8 },
          visible: { opacity: 1, scale: 1 },
        }
      case "scale":
        return {
          hidden: { scale: 0 },
          visible: { scale: 1 },
        }
      default:
        return {
          hidden: { opacity: 0, y: 20 },
          visible: { opacity: 1, y: 0 },
        }
    }
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: startDelay,
        staggerChildren: staggerDelay,
      },
    },
  }

  return (
    <div ref={ref} className={className}>
      <motion.div variants={containerVariants} initial="hidden" animate={isInView ? "visible" : "hidden"}>
        {Array.isArray(children)
          ? children.map((child, index) => (
              <motion.div key={index} variants={getVariants()} transition={{ duration: animationDuration }}>
                {child}
              </motion.div>
            ))
          : children}
      </motion.div>
    </div>
  )
}


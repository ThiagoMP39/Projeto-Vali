import { Clock, CheckCircle2 } from "lucide-react"

export type TimelineStep = {
  title: string
  time: string
  status: "completed" | "in-progress" | "pending"
  description: string
  details: string[]
  icon: () => JSX.Element
}

interface TimelineProps {
  steps: TimelineStep[]
}

export function Timeline({ steps }: TimelineProps) {
  return (
    <>
      {steps.map((step, index) => (
        <div key={index} className="relative mb-12">
          <div
            className={`flex flex-col items-start gap-6 md:flex-row ${index % 2 === 0 ? "md:flex-row-reverse" : ""}`}
          >
            {/* Timeline node */}
            <div className="absolute left-0 flex h-12 w-12 items-center justify-center md:left-1/2 md:-ml-6">
              <div
                className={`flex h-12 w-12 items-center justify-center rounded-full border-2 ${
                  step.status === "completed"
                    ? "border-green-500 bg-green-500 text-white"
                    : step.status === "in-progress"
                      ? "border-primary bg-primary/20 text-primary"
                      : "border-gray-700 bg-gray-900 text-gray-400"
                }`}
              >
                <step.icon />
              </div>
            </div>

            {/* Content */}
            <div className={`ml-20 w-full md:ml-0 md:w-[calc(50%-3rem)] ${index % 2 === 0 ? "md:pr-16" : "md:pl-16"}`}>
              <div className="rounded-xl bg-gray-900 p-6">
                <div className="mb-4 flex items-center justify-between">
                  <h3 className="text-xl font-bold">{step.title}</h3>
                  <div
                    className={`flex items-center gap-2 rounded-full px-3 py-1 text-sm ${
                      step.status === "completed"
                        ? "bg-green-500/20 text-green-500"
                        : step.status === "in-progress"
                          ? "bg-primary/20 text-primary"
                          : "bg-gray-800 text-gray-400"
                    }`}
                  >
                    <Clock className="h-4 w-4" />
                    <span>{step.time}</span>
                  </div>
                </div>
                <p className="mb-4 text-gray-400">{step.description}</p>
                <ul className="grid gap-2">
                  {step.details.map((detail, detailIndex) => (
                    <li key={detailIndex} className="flex items-center gap-2">
                      <CheckCircle2
                        className={`h-4 w-4 ${
                          step.status === "completed"
                            ? "text-green-500"
                            : step.status === "in-progress"
                              ? "text-primary"
                              : "text-gray-600"
                        }`}
                      />
                      <span className="text-sm text-gray-300">{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      ))}
    </>
  )
}

export const timelineSteps: TimelineStep[] = [
  {
    title: "Etapa 1: Iniciação do Projeto",
    time: "1 semana",
    status: "completed",
    description: "Reunião inicial do projeto e planejamento inicial.",
    details: ["Levantamento de requisitos", "Identificação de stakeholders", "Alocação de orçamento"],
    icon: () => <Clock className="h-5 w-5" />,
  },
  {
    title: "Etapa 2: Design e Desenvolvimento",
    time: "4 semanas",
    status: "in-progress",
    description: "Design de UI/UX e desenvolvimento front-end/back-end.",
    details: ["Wireframing", "Prototipagem", "Codificação", "Testes"],
    icon: () => <CheckCircle2 className="h-5 w-5" />,
  },
  {
    title: "Etapa 3: Testes e Implantação",
    time: "2 semanas",
    status: "pending",
    description: "Testes completos e implantação em produção.",
    details: ["Testes unitários", "Testes de integração", "Implantação", "Monitoramento pós-lançamento"],
    icon: () => <Clock className="h-5 w-5" />,
  },
]

